﻿namespace LedMapper
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.edtFontWidth = new System.Windows.Forms.NumericUpDown();
            this.edtFontHeight = new System.Windows.Forms.NumericUpDown();
            this.pnlMapImage = new System.Windows.Forms.Panel();
            this.edtHexArray = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblWarning = new System.Windows.Forms.Label();
            this.btnZigZag = new System.Windows.Forms.Button();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.btnRestore = new System.Windows.Forms.Button();
            this.btnParse = new System.Windows.Forms.Button();
            this.btnRedo = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnColor8 = new System.Windows.Forms.Button();
            this.btnColor7 = new System.Windows.Forms.Button();
            this.btnRightToUp = new System.Windows.Forms.Button();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.btnColor6 = new System.Windows.Forms.Button();
            this.btnRightToDown = new System.Windows.Forms.Button();
            this.btnColor5 = new System.Windows.Forms.Button();
            this.btnLeftToUp = new System.Windows.Forms.Button();
            this.btnColor4 = new System.Windows.Forms.Button();
            this.btnColor3 = new System.Windows.Forms.Button();
            this.btnLeftToDown = new System.Windows.Forms.Button();
            this.btnColor2 = new System.Windows.Forms.Button();
            this.btnDownToRight = new System.Windows.Forms.Button();
            this.btnColor1 = new System.Windows.Forms.Button();
            this.btnDownToLeft = new System.Windows.Forms.Button();
            this.btnTopToRight = new System.Windows.Forms.Button();
            this.btnTopToLeft = new System.Windows.Forms.Button();
            this.chkRightDown = new System.Windows.Forms.CheckBox();
            this.chkLeftDown = new System.Windows.Forms.CheckBox();
            this.chkRightTop = new System.Windows.Forms.CheckBox();
            this.chkLeftTop = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.edtNextIndex = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblIndex = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.rbDec = new System.Windows.Forms.RadioButton();
            this.rbHex = new System.Windows.Forms.RadioButton();
            this.lblWarning2 = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.pnlShowSize = new System.Windows.Forms.Panel();
            this.lblShowSize = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontHeight)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtNextIndex)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.pnlShowSize.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Размер матрицы (Ш x В)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(205, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "x";
            // 
            // edtFontWidth
            // 
            this.edtFontWidth.Location = new System.Drawing.Point(148, 9);
            this.edtFontWidth.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtFontWidth.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.edtFontWidth.Name = "edtFontWidth";
            this.edtFontWidth.Size = new System.Drawing.Size(51, 20);
            this.edtFontWidth.TabIndex = 1;
            this.edtFontWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFontWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtFontWidth.ValueChanged += new System.EventHandler(this.matrixSizeChanged);
            // 
            // edtFontHeight
            // 
            this.edtFontHeight.Location = new System.Drawing.Point(223, 9);
            this.edtFontHeight.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtFontHeight.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.edtFontHeight.Name = "edtFontHeight";
            this.edtFontHeight.Size = new System.Drawing.Size(51, 20);
            this.edtFontHeight.TabIndex = 3;
            this.edtFontHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFontHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtFontHeight.ValueChanged += new System.EventHandler(this.matrixSizeChanged);
            // 
            // pnlMapImage
            // 
            this.pnlMapImage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMapImage.Location = new System.Drawing.Point(0, 0);
            this.pnlMapImage.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMapImage.Name = "pnlMapImage";
            this.pnlMapImage.Size = new System.Drawing.Size(723, 618);
            this.pnlMapImage.TabIndex = 0;
            this.toolTip1.SetToolTip(this.pnlMapImage, "Карта индексов");
            this.pnlMapImage.Paint += new System.Windows.Forms.PaintEventHandler(this.imagePaint);
            this.pnlMapImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlCharImage_MouseDown);
            this.pnlMapImage.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlMapImage_MouseMove);
            this.pnlMapImage.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlMapImage_MouseUp);
            this.pnlMapImage.Resize += new System.EventHandler(this.pnlMapImage_Resize);
            // 
            // edtHexArray
            // 
            this.edtHexArray.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.edtHexArray.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.edtHexArray.Font = new System.Drawing.Font("Courier New", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edtHexArray.Location = new System.Drawing.Point(0, 0);
            this.edtHexArray.Margin = new System.Windows.Forms.Padding(0);
            this.edtHexArray.Multiline = true;
            this.edtHexArray.Name = "edtHexArray";
            this.edtHexArray.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.edtHexArray.Size = new System.Drawing.Size(723, 618);
            this.edtHexArray.TabIndex = 7;
            this.edtHexArray.WordWrap = false;
            this.edtHexArray.TextChanged += new System.EventHandler(this.edtHexArray_TextChanged);
            // 
            // toolTip1
            // 
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // lblWarning
            // 
            this.lblWarning.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblWarning.Location = new System.Drawing.Point(836, 32);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(100, 13);
            this.lblWarning.TabIndex = 9;
            this.lblWarning.Text = "Ошибка";
            this.lblWarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblWarning, "Карта индексов имеет повторяющиеся \r\nзначения индексов.\r\n\r\nСохранение недоступно." +
        "\r\n");
            this.lblWarning.Visible = false;
            // 
            // btnZigZag
            // 
            this.btnZigZag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnZigZag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZigZag.ImageIndex = 4;
            this.btnZigZag.ImageList = this.imageList;
            this.btnZigZag.Location = new System.Drawing.Point(763, 127);
            this.btnZigZag.Margin = new System.Windows.Forms.Padding(0);
            this.btnZigZag.Name = "btnZigZag";
            this.btnZigZag.Size = new System.Drawing.Size(127, 127);
            this.btnZigZag.TabIndex = 20;
            this.toolTip1.SetToolTip(this.btnZigZag, "Нажмите для выбора типа матрицы - параллельная или зигзаг");
            this.btnZigZag.UseVisualStyleBackColor = true;
            this.btnZigZag.Click += new System.EventHandler(this.btnZigZag_Click);
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "parallel-d2u.png");
            this.imageList.Images.SetKeyName(1, "parallel-l2r.png");
            this.imageList.Images.SetKeyName(2, "parallel-r2l.png");
            this.imageList.Images.SetKeyName(3, "parallel-u2d.png");
            this.imageList.Images.SetKeyName(4, "zigzag-h.png");
            this.imageList.Images.SetKeyName(5, "zigzag-v.png");
            // 
            // btnRestore
            // 
            this.btnRestore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestore.Image = global::LedMapper.Properties.Resources.RefreshDocViewHS;
            this.btnRestore.Location = new System.Drawing.Point(732, 40);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(189, 28);
            this.btnRestore.TabIndex = 8;
            this.btnRestore.Text = "Восстановить из карты";
            this.btnRestore.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRestore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnRestore, "Сформировать код  в закладке \"Скетч\"\r\nиз карты индексов с закладки \"Карта\".\r\n\r\nСф" +
        "ормированный код вставьте в скетч \r\nпроекта в файл index_map.ino");
            this.btnRestore.UseVisualStyleBackColor = true;
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // btnParse
            // 
            this.btnParse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnParse.Enabled = false;
            this.btnParse.Image = global::LedMapper.Properties.Resources.RenameFolderHS;
            this.btnParse.Location = new System.Drawing.Point(732, 73);
            this.btnParse.Name = "btnParse";
            this.btnParse.Size = new System.Drawing.Size(189, 28);
            this.btnParse.TabIndex = 8;
            this.btnParse.Text = "Карта из кода";
            this.btnParse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnParse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnParse, "Перестроить карту индексов в закладке \"Карта\"\r\nиз кода скетча, помещенного в закл" +
        "адку \"Скетч\".");
            this.btnParse.UseVisualStyleBackColor = true;
            this.btnParse.Click += new System.EventHandler(this.btnParse_Click);
            // 
            // btnRedo
            // 
            this.btnRedo.Enabled = false;
            this.btnRedo.Image = global::LedMapper.Properties.Resources.Edit_RedoHS;
            this.btnRedo.Location = new System.Drawing.Point(325, 7);
            this.btnRedo.Name = "btnRedo";
            this.btnRedo.Size = new System.Drawing.Size(24, 24);
            this.btnRedo.TabIndex = 3;
            this.btnRedo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnRedo, "Вернуть");
            this.btnRedo.UseVisualStyleBackColor = true;
            this.btnRedo.Click += new System.EventHandler(this.btnRedo_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Enabled = false;
            this.btnUndo.Image = global::LedMapper.Properties.Resources.Edit_UndoHS;
            this.btnUndo.Location = new System.Drawing.Point(295, 7);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(24, 24);
            this.btnUndo.TabIndex = 3;
            this.btnUndo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnUndo, "Отменить");
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Image = global::LedMapper.Properties.Resources.NewDocumentHS;
            this.btnClear.Location = new System.Drawing.Point(624, 7);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 24);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "  Очистить";
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnClear, "Очистить карту индексов");
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Enabled = false;
            this.btnSave.Image = global::LedMapper.Properties.Resources.saveHS;
            this.btnSave.Location = new System.Drawing.Point(836, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 24);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "  Сохранить";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnSave, "Сохранить карту индексов в файл");
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpen.Image = global::LedMapper.Properties.Resources.openHS;
            this.btnOpen.Location = new System.Drawing.Point(730, 7);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(100, 24);
            this.btnOpen.TabIndex = 8;
            this.btnOpen.Text = "  Открыть";
            this.btnOpen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOpen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnOpen, "Загрузить карту индексов из файла");
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(5, 33);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(935, 644);
            this.tabControl.TabIndex = 4;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.btnColor8);
            this.tabPage1.Controls.Add(this.btnColor7);
            this.tabPage1.Controls.Add(this.btnRightToUp);
            this.tabPage1.Controls.Add(this.btnColor6);
            this.tabPage1.Controls.Add(this.btnRightToDown);
            this.tabPage1.Controls.Add(this.btnColor5);
            this.tabPage1.Controls.Add(this.btnLeftToUp);
            this.tabPage1.Controls.Add(this.btnColor4);
            this.tabPage1.Controls.Add(this.btnColor3);
            this.tabPage1.Controls.Add(this.btnLeftToDown);
            this.tabPage1.Controls.Add(this.btnColor2);
            this.tabPage1.Controls.Add(this.btnDownToRight);
            this.tabPage1.Controls.Add(this.btnColor1);
            this.tabPage1.Controls.Add(this.btnDownToLeft);
            this.tabPage1.Controls.Add(this.btnTopToRight);
            this.tabPage1.Controls.Add(this.btnTopToLeft);
            this.tabPage1.Controls.Add(this.chkRightDown);
            this.tabPage1.Controls.Add(this.chkLeftDown);
            this.tabPage1.Controls.Add(this.chkRightTop);
            this.tabPage1.Controls.Add(this.chkLeftTop);
            this.tabPage1.Controls.Add(this.btnZigZag);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.edtNextIndex);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.lblIndex);
            this.tabPage1.Controls.Add(this.lblCurrent);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.pnlMapImage);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(927, 618);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Карта";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(752, 502);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(174, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "- индекс задан, начало сегмента";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = global::LedMapper.Properties.Resources.circle;
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(729, 497);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(23, 23);
            this.panel3.TabIndex = 26;
            // 
            // btnColor8
            // 
            this.btnColor8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnColor8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor8.ForeColor = System.Drawing.Color.White;
            this.btnColor8.Location = new System.Drawing.Point(857, 344);
            this.btnColor8.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor8.Name = "btnColor8";
            this.btnColor8.Size = new System.Drawing.Size(30, 29);
            this.btnColor8.TabIndex = 7;
            this.btnColor8.TabStop = false;
            this.btnColor8.Tag = "7";
            this.btnColor8.UseVisualStyleBackColor = false;
            this.btnColor8.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor7
            // 
            this.btnColor7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnColor7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor7.ForeColor = System.Drawing.Color.White;
            this.btnColor7.Location = new System.Drawing.Point(827, 344);
            this.btnColor7.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor7.Name = "btnColor7";
            this.btnColor7.Size = new System.Drawing.Size(30, 29);
            this.btnColor7.TabIndex = 6;
            this.btnColor7.TabStop = false;
            this.btnColor7.Tag = "6";
            this.btnColor7.UseVisualStyleBackColor = false;
            this.btnColor7.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnRightToUp
            // 
            this.btnRightToUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRightToUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRightToUp.ImageIndex = 7;
            this.btnRightToUp.ImageList = this.imageList2;
            this.btnRightToUp.Location = new System.Drawing.Point(889, 190);
            this.btnRightToUp.Name = "btnRightToUp";
            this.btnRightToUp.Size = new System.Drawing.Size(30, 64);
            this.btnRightToUp.TabIndex = 13;
            this.btnRightToUp.UseVisualStyleBackColor = true;
            this.btnRightToUp.Click += new System.EventHandler(this.btnRightToUp_Click);
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "arrow-dn.png");
            this.imageList2.Images.SetKeyName(1, "arrow-dn-g.png");
            this.imageList2.Images.SetKeyName(2, "arrow-left.png");
            this.imageList2.Images.SetKeyName(3, "arrow-left-g.png");
            this.imageList2.Images.SetKeyName(4, "arrow-right.png");
            this.imageList2.Images.SetKeyName(5, "arrow-right-g.png");
            this.imageList2.Images.SetKeyName(6, "arrow-up.png");
            this.imageList2.Images.SetKeyName(7, "arrow-up-g.png");
            // 
            // btnColor6
            // 
            this.btnColor6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnColor6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor6.ForeColor = System.Drawing.Color.White;
            this.btnColor6.Location = new System.Drawing.Point(797, 344);
            this.btnColor6.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor6.Name = "btnColor6";
            this.btnColor6.Size = new System.Drawing.Size(30, 29);
            this.btnColor6.TabIndex = 5;
            this.btnColor6.TabStop = false;
            this.btnColor6.Tag = "5";
            this.btnColor6.UseVisualStyleBackColor = false;
            this.btnColor6.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnRightToDown
            // 
            this.btnRightToDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRightToDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRightToDown.ImageIndex = 1;
            this.btnRightToDown.ImageList = this.imageList2;
            this.btnRightToDown.Location = new System.Drawing.Point(889, 127);
            this.btnRightToDown.Name = "btnRightToDown";
            this.btnRightToDown.Size = new System.Drawing.Size(30, 64);
            this.btnRightToDown.TabIndex = 12;
            this.btnRightToDown.UseVisualStyleBackColor = true;
            this.btnRightToDown.Click += new System.EventHandler(this.btnRightToDown_Click);
            // 
            // btnColor5
            // 
            this.btnColor5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnColor5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor5.ForeColor = System.Drawing.Color.White;
            this.btnColor5.Location = new System.Drawing.Point(767, 344);
            this.btnColor5.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor5.Name = "btnColor5";
            this.btnColor5.Size = new System.Drawing.Size(30, 29);
            this.btnColor5.TabIndex = 4;
            this.btnColor5.TabStop = false;
            this.btnColor5.Tag = "4";
            this.btnColor5.UseVisualStyleBackColor = false;
            this.btnColor5.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnLeftToUp
            // 
            this.btnLeftToUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLeftToUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeftToUp.ImageIndex = 7;
            this.btnLeftToUp.ImageList = this.imageList2;
            this.btnLeftToUp.Location = new System.Drawing.Point(734, 190);
            this.btnLeftToUp.Name = "btnLeftToUp";
            this.btnLeftToUp.Size = new System.Drawing.Size(30, 64);
            this.btnLeftToUp.TabIndex = 18;
            this.btnLeftToUp.UseVisualStyleBackColor = true;
            this.btnLeftToUp.Click += new System.EventHandler(this.btnLeftToUp_Click);
            // 
            // btnColor4
            // 
            this.btnColor4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnColor4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor4.ForeColor = System.Drawing.Color.White;
            this.btnColor4.Location = new System.Drawing.Point(857, 315);
            this.btnColor4.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor4.Name = "btnColor4";
            this.btnColor4.Size = new System.Drawing.Size(30, 29);
            this.btnColor4.TabIndex = 3;
            this.btnColor4.TabStop = false;
            this.btnColor4.Tag = "3";
            this.btnColor4.UseVisualStyleBackColor = false;
            this.btnColor4.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor3
            // 
            this.btnColor3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor3.BackColor = System.Drawing.Color.Purple;
            this.btnColor3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor3.ForeColor = System.Drawing.Color.White;
            this.btnColor3.Location = new System.Drawing.Point(827, 315);
            this.btnColor3.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor3.Name = "btnColor3";
            this.btnColor3.Size = new System.Drawing.Size(30, 29);
            this.btnColor3.TabIndex = 2;
            this.btnColor3.TabStop = false;
            this.btnColor3.Tag = "2";
            this.btnColor3.UseVisualStyleBackColor = false;
            this.btnColor3.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnLeftToDown
            // 
            this.btnLeftToDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLeftToDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeftToDown.ImageIndex = 1;
            this.btnLeftToDown.ImageList = this.imageList2;
            this.btnLeftToDown.Location = new System.Drawing.Point(734, 127);
            this.btnLeftToDown.Name = "btnLeftToDown";
            this.btnLeftToDown.Size = new System.Drawing.Size(30, 64);
            this.btnLeftToDown.TabIndex = 19;
            this.btnLeftToDown.UseVisualStyleBackColor = true;
            this.btnLeftToDown.Click += new System.EventHandler(this.btnLeftToDown_Click);
            // 
            // btnColor2
            // 
            this.btnColor2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor2.BackColor = System.Drawing.Color.Blue;
            this.btnColor2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor2.ForeColor = System.Drawing.Color.White;
            this.btnColor2.Location = new System.Drawing.Point(797, 315);
            this.btnColor2.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(30, 29);
            this.btnColor2.TabIndex = 1;
            this.btnColor2.TabStop = false;
            this.btnColor2.Tag = "1";
            this.btnColor2.UseVisualStyleBackColor = false;
            this.btnColor2.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnDownToRight
            // 
            this.btnDownToRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDownToRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownToRight.ImageIndex = 5;
            this.btnDownToRight.ImageList = this.imageList2;
            this.btnDownToRight.Location = new System.Drawing.Point(763, 253);
            this.btnDownToRight.Name = "btnDownToRight";
            this.btnDownToRight.Size = new System.Drawing.Size(64, 30);
            this.btnDownToRight.TabIndex = 16;
            this.btnDownToRight.UseVisualStyleBackColor = true;
            this.btnDownToRight.Click += new System.EventHandler(this.btnDownToRight_Click);
            // 
            // btnColor1
            // 
            this.btnColor1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColor1.BackColor = System.Drawing.Color.Green;
            this.btnColor1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor1.ForeColor = System.Drawing.Color.White;
            this.btnColor1.Location = new System.Drawing.Point(767, 315);
            this.btnColor1.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(30, 29);
            this.btnColor1.TabIndex = 0;
            this.btnColor1.TabStop = false;
            this.btnColor1.Tag = "0";
            this.btnColor1.UseVisualStyleBackColor = false;
            this.btnColor1.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnDownToLeft
            // 
            this.btnDownToLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDownToLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownToLeft.ImageIndex = 3;
            this.btnDownToLeft.ImageList = this.imageList2;
            this.btnDownToLeft.Location = new System.Drawing.Point(826, 253);
            this.btnDownToLeft.Name = "btnDownToLeft";
            this.btnDownToLeft.Size = new System.Drawing.Size(64, 30);
            this.btnDownToLeft.TabIndex = 15;
            this.btnDownToLeft.UseVisualStyleBackColor = true;
            this.btnDownToLeft.Click += new System.EventHandler(this.btnDownToLeft_Click);
            // 
            // btnTopToRight
            // 
            this.btnTopToRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTopToRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTopToRight.ImageIndex = 5;
            this.btnTopToRight.ImageList = this.imageList2;
            this.btnTopToRight.Location = new System.Drawing.Point(763, 98);
            this.btnTopToRight.Name = "btnTopToRight";
            this.btnTopToRight.Size = new System.Drawing.Size(64, 30);
            this.btnTopToRight.TabIndex = 9;
            this.btnTopToRight.UseVisualStyleBackColor = true;
            this.btnTopToRight.Click += new System.EventHandler(this.btnTopToRight_Click);
            // 
            // btnTopToLeft
            // 
            this.btnTopToLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTopToLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTopToLeft.ImageIndex = 3;
            this.btnTopToLeft.ImageList = this.imageList2;
            this.btnTopToLeft.Location = new System.Drawing.Point(826, 98);
            this.btnTopToLeft.Name = "btnTopToLeft";
            this.btnTopToLeft.Size = new System.Drawing.Size(64, 30);
            this.btnTopToLeft.TabIndex = 10;
            this.btnTopToLeft.UseVisualStyleBackColor = true;
            this.btnTopToLeft.Click += new System.EventHandler(this.btnTopToLeft_Click);
            // 
            // chkRightDown
            // 
            this.chkRightDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRightDown.AutoSize = true;
            this.chkRightDown.Location = new System.Drawing.Point(896, 262);
            this.chkRightDown.Name = "chkRightDown";
            this.chkRightDown.Size = new System.Drawing.Size(15, 14);
            this.chkRightDown.TabIndex = 14;
            this.chkRightDown.UseVisualStyleBackColor = true;
            this.chkRightDown.CheckedChanged += new System.EventHandler(this.chkRightDown_CheckedChanged);
            // 
            // chkLeftDown
            // 
            this.chkLeftDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkLeftDown.AutoSize = true;
            this.chkLeftDown.Location = new System.Drawing.Point(743, 262);
            this.chkLeftDown.Name = "chkLeftDown";
            this.chkLeftDown.Size = new System.Drawing.Size(15, 14);
            this.chkLeftDown.TabIndex = 17;
            this.chkLeftDown.UseVisualStyleBackColor = true;
            this.chkLeftDown.CheckedChanged += new System.EventHandler(this.chkLeftDown_CheckedChanged);
            // 
            // chkRightTop
            // 
            this.chkRightTop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRightTop.AutoSize = true;
            this.chkRightTop.Location = new System.Drawing.Point(896, 107);
            this.chkRightTop.Name = "chkRightTop";
            this.chkRightTop.Size = new System.Drawing.Size(15, 14);
            this.chkRightTop.TabIndex = 11;
            this.chkRightTop.UseVisualStyleBackColor = true;
            this.chkRightTop.CheckedChanged += new System.EventHandler(this.chkRightTop_CheckedChanged);
            // 
            // chkLeftTop
            // 
            this.chkLeftTop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkLeftTop.AutoSize = true;
            this.chkLeftTop.Location = new System.Drawing.Point(742, 107);
            this.chkLeftTop.Name = "chkLeftTop";
            this.chkLeftTop.Size = new System.Drawing.Size(15, 14);
            this.chkLeftTop.TabIndex = 8;
            this.chkLeftTop.UseVisualStyleBackColor = true;
            this.chkLeftTop.CheckedChanged += new System.EventHandler(this.chkLeftTop_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label12);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(729, 552);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(22, 22);
            this.panel2.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(4, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "0";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(753, 556);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "- индекс задан, дублируется";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(729, 526);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(22, 22);
            this.panel1.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(4, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "0";
            // 
            // edtNextIndex
            // 
            this.edtNextIndex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.edtNextIndex.Location = new System.Drawing.Point(842, 36);
            this.edtNextIndex.Name = "edtNextIndex";
            this.edtNextIndex.Size = new System.Drawing.Size(79, 20);
            this.edtNextIndex.TabIndex = 6;
            this.edtNextIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(728, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "X, Y:";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(728, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Следующий индекс";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(784, 297);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "Цвет сегмента";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(728, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Порядок нумерации в сегменте";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(824, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Индекс:";
            // 
            // lblIndex
            // 
            this.lblIndex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIndex.Location = new System.Drawing.Point(875, 11);
            this.lblIndex.Name = "lblIndex";
            this.lblIndex.Size = new System.Drawing.Size(46, 13);
            this.lblIndex.TabIndex = 5;
            this.lblIndex.Text = "0";
            this.lblIndex.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCurrent
            // 
            this.lblCurrent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCurrent.Location = new System.Drawing.Point(764, 11);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(54, 13);
            this.lblCurrent.TabIndex = 2;
            this.lblCurrent.Text = "[ 0, 0 ]";
            this.lblCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(753, 530);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "- индекс задан, корректен";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(734, 579);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Левая кнопка - включить индекс";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(734, 599);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Правая кнопка - очистить индекс";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.rbDec);
            this.tabPage2.Controls.Add(this.rbHex);
            this.tabPage2.Controls.Add(this.lblWarning2);
            this.tabPage2.Controls.Add(this.edtHexArray);
            this.tabPage2.Controls.Add(this.btnRestore);
            this.tabPage2.Controls.Add(this.btnParse);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(927, 618);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Скетч";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(732, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "Формат:";
            // 
            // rbDec
            // 
            this.rbDec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rbDec.AutoSize = true;
            this.rbDec.Checked = true;
            this.rbDec.Location = new System.Drawing.Point(796, 17);
            this.rbDec.Name = "rbDec";
            this.rbDec.Size = new System.Drawing.Size(45, 17);
            this.rbDec.TabIndex = 10;
            this.rbDec.TabStop = true;
            this.rbDec.Text = "Dec";
            this.rbDec.UseVisualStyleBackColor = true;
            this.rbDec.CheckedChanged += new System.EventHandler(this.HexDec_CheckedChanged);
            // 
            // rbHex
            // 
            this.rbHex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rbHex.AutoSize = true;
            this.rbHex.Location = new System.Drawing.Point(847, 17);
            this.rbHex.Name = "rbHex";
            this.rbHex.Size = new System.Drawing.Size(44, 17);
            this.rbHex.TabIndex = 10;
            this.rbHex.Text = "Hex";
            this.rbHex.UseVisualStyleBackColor = true;
            this.rbHex.CheckedChanged += new System.EventHandler(this.HexDec_CheckedChanged);
            // 
            // lblWarning2
            // 
            this.lblWarning2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblWarning2.ForeColor = System.Drawing.Color.Maroon;
            this.lblWarning2.Location = new System.Drawing.Point(729, 104);
            this.lblWarning2.Name = "lblWarning2";
            this.lblWarning2.Size = new System.Drawing.Size(189, 26);
            this.lblWarning2.TabIndex = 9;
            this.lblWarning2.Text = "Обнаружены ошибки при разборе текста\r\n";
            this.lblWarning2.Visible = false;
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "map";
            this.saveFileDialog.Title = "Сохранение карты индексов";
            // 
            // openFileDialog
            // 
            this.openFileDialog.DefaultExt = "map";
            this.openFileDialog.Title = "Загрузка карты индексов";
            // 
            // pnlShowSize
            // 
            this.pnlShowSize.BackColor = System.Drawing.Color.LightCyan;
            this.pnlShowSize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlShowSize.Controls.Add(this.lblShowSize);
            this.pnlShowSize.Location = new System.Drawing.Point(464, 12);
            this.pnlShowSize.Margin = new System.Windows.Forms.Padding(0);
            this.pnlShowSize.Name = "pnlShowSize";
            this.pnlShowSize.Size = new System.Drawing.Size(68, 24);
            this.pnlShowSize.TabIndex = 10;
            this.pnlShowSize.Visible = false;
            // 
            // lblShowSize
            // 
            this.lblShowSize.BackColor = System.Drawing.Color.Transparent;
            this.lblShowSize.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShowSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblShowSize.Location = new System.Drawing.Point(0, 0);
            this.lblShowSize.Margin = new System.Windows.Forms.Padding(0);
            this.lblShowSize.Name = "lblShowSize";
            this.lblShowSize.Size = new System.Drawing.Size(66, 22);
            this.lblShowSize.TabIndex = 0;
            this.lblShowSize.Text = "127 x 127";
            this.lblShowSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 681);
            this.Controls.Add(this.pnlShowSize);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.edtFontHeight);
            this.Controls.Add(this.edtFontWidth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRedo);
            this.Controls.Add(this.btnUndo);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnOpen);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(960, 720);
            this.Name = "Form1";
            this.Text = "Карта матрицы";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.edtFontWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontHeight)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtNextIndex)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnlShowSize.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown edtFontWidth;
        private System.Windows.Forms.NumericUpDown edtFontHeight;
        private System.Windows.Forms.Panel pnlMapImage;
        private System.Windows.Forms.TextBox edtHexArray;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.NumericUpDown edtNextIndex;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.Label lblIndex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnTopToLeft;
        private System.Windows.Forms.CheckBox chkRightDown;
        private System.Windows.Forms.CheckBox chkLeftDown;
        private System.Windows.Forms.CheckBox chkRightTop;
        private System.Windows.Forms.CheckBox chkLeftTop;
        private System.Windows.Forms.Button btnZigZag;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.Button btnRightToUp;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Button btnRightToDown;
        private System.Windows.Forms.Button btnLeftToUp;
        private System.Windows.Forms.Button btnLeftToDown;
        private System.Windows.Forms.Button btnDownToRight;
        private System.Windows.Forms.Button btnDownToLeft;
        private System.Windows.Forms.Button btnTopToRight;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnParse;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.RadioButton rbDec;
        private System.Windows.Forms.RadioButton rbHex;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblWarning2;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnRedo;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button btnColor8;
        private System.Windows.Forms.Button btnColor7;
        private System.Windows.Forms.Button btnColor6;
        private System.Windows.Forms.Button btnColor5;
        private System.Windows.Forms.Button btnColor4;
        private System.Windows.Forms.Button btnColor3;
        private System.Windows.Forms.Button btnColor2;
        private System.Windows.Forms.Button btnColor1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel pnlShowSize;
        private System.Windows.Forms.Label lblShowSize;
    }
}

