﻿namespace LedMapper
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCrllIndex = new System.Windows.Forms.Label();
            this.edtCellIndex = new System.Windows.Forms.NumericUpDown();
            this.chkSegmentStart = new System.Windows.Forms.CheckBox();
            this.btnColor8 = new System.Windows.Forms.Button();
            this.btnColor7 = new System.Windows.Forms.Button();
            this.btnColor6 = new System.Windows.Forms.Button();
            this.btnColor5 = new System.Windows.Forms.Button();
            this.btnColor4 = new System.Windows.Forms.Button();
            this.btnColor3 = new System.Windows.Forms.Button();
            this.btnColor2 = new System.Windows.Forms.Button();
            this.btnColor1 = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.edtCellIndex)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "X,Y:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Индекс:";
            // 
            // lblCrllIndex
            // 
            this.lblCrllIndex.AutoSize = true;
            this.lblCrllIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCrllIndex.Location = new System.Drawing.Point(38, 8);
            this.lblCrllIndex.Name = "lblCrllIndex";
            this.lblCrllIndex.Size = new System.Drawing.Size(45, 13);
            this.lblCrllIndex.TabIndex = 3;
            this.lblCrllIndex.Text = "[ 0, 0 ]";
            this.lblCrllIndex.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // edtCellIndex
            // 
            this.edtCellIndex.Location = new System.Drawing.Point(172, 6);
            this.edtCellIndex.Name = "edtCellIndex";
            this.edtCellIndex.Size = new System.Drawing.Size(55, 20);
            this.edtCellIndex.TabIndex = 7;
            this.edtCellIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkSegmentStart
            // 
            this.chkSegmentStart.AutoSize = true;
            this.chkSegmentStart.Location = new System.Drawing.Point(8, 28);
            this.chkSegmentStart.Name = "chkSegmentStart";
            this.chkSegmentStart.Size = new System.Drawing.Size(114, 17);
            this.chkSegmentStart.TabIndex = 8;
            this.chkSegmentStart.Text = "Начало сегмента";
            this.chkSegmentStart.UseVisualStyleBackColor = true;
            this.chkSegmentStart.CheckedChanged += new System.EventHandler(this.chkSegmentStart_CheckedChanged);
            // 
            // btnColor8
            // 
            this.btnColor8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnColor8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor8.ForeColor = System.Drawing.Color.White;
            this.btnColor8.Location = new System.Drawing.Point(97, 81);
            this.btnColor8.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor8.Name = "btnColor8";
            this.btnColor8.Size = new System.Drawing.Size(23, 22);
            this.btnColor8.TabIndex = 16;
            this.btnColor8.TabStop = false;
            this.btnColor8.Tag = "7";
            this.btnColor8.UseVisualStyleBackColor = false;
            this.btnColor8.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor7
            // 
            this.btnColor7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnColor7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor7.ForeColor = System.Drawing.Color.White;
            this.btnColor7.Location = new System.Drawing.Point(67, 81);
            this.btnColor7.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor7.Name = "btnColor7";
            this.btnColor7.Size = new System.Drawing.Size(23, 22);
            this.btnColor7.TabIndex = 15;
            this.btnColor7.TabStop = false;
            this.btnColor7.Tag = "6";
            this.btnColor7.UseVisualStyleBackColor = false;
            this.btnColor7.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor6
            // 
            this.btnColor6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnColor6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor6.ForeColor = System.Drawing.Color.White;
            this.btnColor6.Location = new System.Drawing.Point(37, 81);
            this.btnColor6.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor6.Name = "btnColor6";
            this.btnColor6.Size = new System.Drawing.Size(23, 22);
            this.btnColor6.TabIndex = 14;
            this.btnColor6.TabStop = false;
            this.btnColor6.Tag = "5";
            this.btnColor6.UseVisualStyleBackColor = false;
            this.btnColor6.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor5
            // 
            this.btnColor5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnColor5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor5.ForeColor = System.Drawing.Color.White;
            this.btnColor5.Location = new System.Drawing.Point(7, 81);
            this.btnColor5.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor5.Name = "btnColor5";
            this.btnColor5.Size = new System.Drawing.Size(23, 22);
            this.btnColor5.TabIndex = 13;
            this.btnColor5.TabStop = false;
            this.btnColor5.Tag = "4";
            this.btnColor5.UseVisualStyleBackColor = false;
            this.btnColor5.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor4
            // 
            this.btnColor4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnColor4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor4.ForeColor = System.Drawing.Color.White;
            this.btnColor4.Location = new System.Drawing.Point(97, 52);
            this.btnColor4.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor4.Name = "btnColor4";
            this.btnColor4.Size = new System.Drawing.Size(23, 22);
            this.btnColor4.TabIndex = 12;
            this.btnColor4.TabStop = false;
            this.btnColor4.Tag = "3";
            this.btnColor4.UseVisualStyleBackColor = false;
            this.btnColor4.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor3
            // 
            this.btnColor3.BackColor = System.Drawing.Color.Purple;
            this.btnColor3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor3.ForeColor = System.Drawing.Color.White;
            this.btnColor3.Location = new System.Drawing.Point(67, 52);
            this.btnColor3.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor3.Name = "btnColor3";
            this.btnColor3.Size = new System.Drawing.Size(23, 22);
            this.btnColor3.TabIndex = 11;
            this.btnColor3.TabStop = false;
            this.btnColor3.Tag = "2";
            this.btnColor3.UseVisualStyleBackColor = false;
            this.btnColor3.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor2
            // 
            this.btnColor2.BackColor = System.Drawing.Color.Blue;
            this.btnColor2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor2.ForeColor = System.Drawing.Color.White;
            this.btnColor2.Location = new System.Drawing.Point(37, 52);
            this.btnColor2.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(23, 22);
            this.btnColor2.TabIndex = 10;
            this.btnColor2.TabStop = false;
            this.btnColor2.Tag = "1";
            this.btnColor2.UseVisualStyleBackColor = false;
            this.btnColor2.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnColor1
            // 
            this.btnColor1.BackColor = System.Drawing.Color.Green;
            this.btnColor1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnColor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnColor1.ForeColor = System.Drawing.Color.White;
            this.btnColor1.Location = new System.Drawing.Point(7, 52);
            this.btnColor1.Margin = new System.Windows.Forms.Padding(0);
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(23, 22);
            this.btnColor1.TabIndex = 9;
            this.btnColor1.TabStop = false;
            this.btnColor1.Tag = "0";
            this.btnColor1.UseVisualStyleBackColor = false;
            this.btnColor1.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(149, 53);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(77, 24);
            this.btnOk.TabIndex = 17;
            this.btnOk.Text = "Применить";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(148, 79);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(77, 24);
            this.btnCancel.TabIndex = 17;
            this.btnCancel.Text = "Отменить";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnOk);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnColor8);
            this.panel1.Controls.Add(this.lblCrllIndex);
            this.panel1.Controls.Add(this.btnColor7);
            this.panel1.Controls.Add(this.edtCellIndex);
            this.panel1.Controls.Add(this.btnColor6);
            this.panel1.Controls.Add(this.chkSegmentStart);
            this.panel1.Controls.Add(this.btnColor5);
            this.panel1.Controls.Add(this.btnColor1);
            this.panel1.Controls.Add(this.btnColor4);
            this.panel1.Controls.Add(this.btnColor2);
            this.panel1.Controls.Add(this.btnColor3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 110);
            this.panel1.TabIndex = 18;
            // 
            // EditForm
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(234, 110);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "EditForm";
            ((System.ComponentModel.ISupportInitialize)(this.edtCellIndex)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCrllIndex;
        private System.Windows.Forms.NumericUpDown edtCellIndex;
        private System.Windows.Forms.CheckBox chkSegmentStart;
        private System.Windows.Forms.Button btnColor8;
        private System.Windows.Forms.Button btnColor7;
        private System.Windows.Forms.Button btnColor6;
        private System.Windows.Forms.Button btnColor5;
        private System.Windows.Forms.Button btnColor4;
        private System.Windows.Forms.Button btnColor3;
        private System.Windows.Forms.Button btnColor2;
        private System.Windows.Forms.Button btnColor1;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel panel1;
    }
}