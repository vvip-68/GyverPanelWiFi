﻿namespace JinxFramer
{
    partial class frmMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlCanvas = new System.Windows.Forms.Panel();
            this.lblFile = new System.Windows.Forms.Label();
            this.edtFileName = new System.Windows.Forms.TextBox();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.trkFrames = new System.Windows.Forms.TrackBar();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.edtWidth = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.edtHeight = new System.Windows.Forms.NumericUpDown();
            this.lblWarning = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMatrixType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbColorOrder = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.trkSpeed = new System.Windows.Forms.TrackBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.chkGrid = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnFragSave = new System.Windows.Forms.Button();
            this.edtFragEnd = new System.Windows.Forms.NumericUpDown();
            this.btnFragEnd = new System.Windows.Forms.Button();
            this.edtFragStart = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFragStart = new System.Windows.Forms.Button();
            this.lblFirstFrame = new System.Windows.Forms.Label();
            this.lblTotalFrames = new System.Windows.Forms.Label();
            this.lblCurrentFrame = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCanvas
            // 
            this.pnlCanvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCanvas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCanvas.Location = new System.Drawing.Point(10, 10);
            this.pnlCanvas.Name = "pnlCanvas";
            this.pnlCanvas.Size = new System.Drawing.Size(584, 448);
            this.pnlCanvas.TabIndex = 0;
            this.pnlCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlCanvas_Paint);
            this.pnlCanvas.Resize += new System.EventHandler(this.pnlCanvas_Resize);
            // 
            // lblFile
            // 
            this.lblFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(7, 531);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(42, 13);
            this.lblFile.TabIndex = 2;
            this.lblFile.Text = "Файл: ";
            // 
            // edtFileName
            // 
            this.edtFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.edtFileName.Location = new System.Drawing.Point(55, 529);
            this.edtFileName.Name = "edtFileName";
            this.edtFileName.ReadOnly = true;
            this.edtFileName.Size = new System.Drawing.Size(458, 20);
            this.edtFileName.TabIndex = 3;
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpenFile.Location = new System.Drawing.Point(519, 526);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(75, 23);
            this.btnOpenFile.TabIndex = 4;
            this.btnOpenFile.Text = "Выбрать...";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // trkFrames
            // 
            this.trkFrames.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trkFrames.AutoSize = false;
            this.trkFrames.Enabled = false;
            this.trkFrames.Location = new System.Drawing.Point(4, 464);
            this.trkFrames.Name = "trkFrames";
            this.trkFrames.Size = new System.Drawing.Size(597, 31);
            this.trkFrames.TabIndex = 1;
            this.trkFrames.ValueChanged += new System.EventHandler(this.trkFrames_ValueChanged);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "*.out|*out";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "W";
            // 
            // edtWidth
            // 
            this.edtWidth.Location = new System.Drawing.Point(27, 4);
            this.edtWidth.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtWidth.Name = "edtWidth";
            this.edtWidth.Size = new System.Drawing.Size(49, 20);
            this.edtWidth.TabIndex = 6;
            this.edtWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtWidth.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "x H";
            // 
            // edtHeight
            // 
            this.edtHeight.Location = new System.Drawing.Point(111, 4);
            this.edtHeight.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtHeight.Name = "edtHeight";
            this.edtHeight.Size = new System.Drawing.Size(49, 20);
            this.edtHeight.TabIndex = 8;
            this.edtHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtHeight.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // lblWarning
            // 
            this.lblWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblWarning.Location = new System.Drawing.Point(3, 50);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(171, 49);
            this.lblWarning.TabIndex = 9;
            this.lblWarning.Text = "Размер матрицы не соответствует размеру кадра в  загруженном файле";
            this.lblWarning.Visible = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Controls.Add(this.label5);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.lblWarning);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.cbMatrixType);
            this.flowLayoutPanel1.Controls.Add(this.label6);
            this.flowLayoutPanel1.Controls.Add(this.cbColorOrder);
            this.flowLayoutPanel1.Controls.Add(this.label4);
            this.flowLayoutPanel1.Controls.Add(this.trkSpeed);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.chkGrid);
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(601, 4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(179, 454);
            this.flowLayoutPanel1.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Размер матрицы";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.edtHeight);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.edtWidth);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(176, 31);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Тип матрицы";
            // 
            // cbMatrixType
            // 
            this.cbMatrixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMatrixType.FormattingEnabled = true;
            this.cbMatrixType.Items.AddRange(new object[] {
            "Лево-Верх строки вправо",
            "Право-Верх строки влево",
            "Лево-Низ строки вправо",
            "Право-Низ строки влево",
            "Лево-Верх зигзаг вправо",
            "Право-Верх зигзаг влево",
            "Лево-Низ зигзаг вправо",
            "Право-Низ зигзаг влево",
            "Лево-Верх колонки вниз",
            "Право-Верх колонки вниз",
            "Лево-Низ колонки вверх",
            "Право-Низ колонки вверх",
            "Лево-Верх зигзаг вниз",
            "Право-Верх зигзаг вниз",
            "Лево-Низ зигзаг вверх",
            "Право-Низ зигзаг вверх"});
            this.cbMatrixType.Location = new System.Drawing.Point(3, 115);
            this.cbMatrixType.Name = "cbMatrixType";
            this.cbMatrixType.Size = new System.Drawing.Size(168, 21);
            this.cbMatrixType.TabIndex = 9;
            this.cbMatrixType.SelectedIndexChanged += new System.EventHandler(this.cbMatrixType_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Порядок цвета";
            // 
            // cbColorOrder
            // 
            this.cbColorOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbColorOrder.FormattingEnabled = true;
            this.cbColorOrder.Items.AddRange(new object[] {
            "RGB",
            "RBG",
            "BGR",
            "BRG",
            "GBR",
            "GRB"});
            this.cbColorOrder.Location = new System.Drawing.Point(3, 155);
            this.cbColorOrder.Name = "cbColorOrder";
            this.cbColorOrder.Size = new System.Drawing.Size(83, 21);
            this.cbColorOrder.TabIndex = 17;
            this.cbColorOrder.SelectedIndexChanged += new System.EventHandler(this.cbColorOrder_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Скорость;";
            // 
            // trkSpeed
            // 
            this.trkSpeed.AutoSize = false;
            this.trkSpeed.Location = new System.Drawing.Point(3, 195);
            this.trkSpeed.Maximum = 100;
            this.trkSpeed.Minimum = 1;
            this.trkSpeed.Name = "trkSpeed";
            this.trkSpeed.Size = new System.Drawing.Size(171, 33);
            this.trkSpeed.TabIndex = 11;
            this.trkSpeed.Value = 10;
            this.trkSpeed.ValueChanged += new System.EventHandler(this.trkSpeed_ValueChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnStop);
            this.panel2.Controls.Add(this.btnStart);
            this.panel2.Location = new System.Drawing.Point(3, 234);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(176, 36);
            this.panel2.TabIndex = 12;
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Image = ((System.Drawing.Image)(resources.GetObject("btnStop.Image")));
            this.btnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStop.Location = new System.Drawing.Point(89, 4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(80, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "стоп";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Enabled = false;
            this.btnStart.Image = global::JinxFramer.Properties.Resources.play;
            this.btnStart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStart.Location = new System.Drawing.Point(2, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(80, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "старт";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // chkGrid
            // 
            this.chkGrid.AutoSize = true;
            this.chkGrid.Checked = true;
            this.chkGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkGrid.Location = new System.Drawing.Point(3, 276);
            this.chkGrid.Name = "chkGrid";
            this.chkGrid.Size = new System.Drawing.Size(105, 17);
            this.chkGrid.TabIndex = 13;
            this.chkGrid.Text = "Рисовать сетку";
            this.chkGrid.UseVisualStyleBackColor = true;
            this.chkGrid.CheckedChanged += new System.EventHandler(this.chkGrid_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel3.Location = new System.Drawing.Point(3, 299);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(176, 2);
            this.panel3.TabIndex = 18;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnFragSave);
            this.panel4.Controls.Add(this.edtFragEnd);
            this.panel4.Controls.Add(this.btnFragEnd);
            this.panel4.Controls.Add(this.edtFragStart);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.btnFragStart);
            this.panel4.Location = new System.Drawing.Point(3, 307);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(176, 110);
            this.panel4.TabIndex = 19;
            // 
            // btnFragSave
            // 
            this.btnFragSave.Location = new System.Drawing.Point(3, 79);
            this.btnFragSave.Name = "btnFragSave";
            this.btnFragSave.Size = new System.Drawing.Size(170, 23);
            this.btnFragSave.TabIndex = 5;
            this.btnFragSave.Text = "Сохранить фрагмент...";
            this.btnFragSave.UseVisualStyleBackColor = true;
            this.btnFragSave.Click += new System.EventHandler(this.btnFragSave_Click);
            // 
            // edtFragEnd
            // 
            this.edtFragEnd.Location = new System.Drawing.Point(110, 51);
            this.edtFragEnd.Name = "edtFragEnd";
            this.edtFragEnd.Size = new System.Drawing.Size(61, 20);
            this.edtFragEnd.TabIndex = 4;
            this.edtFragEnd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFragEnd.ValueChanged += new System.EventHandler(this.edtFragEnd_ValueChanged);
            // 
            // btnFragEnd
            // 
            this.btnFragEnd.Location = new System.Drawing.Point(3, 48);
            this.btnFragEnd.Name = "btnFragEnd";
            this.btnFragEnd.Size = new System.Drawing.Size(90, 23);
            this.btnFragEnd.TabIndex = 3;
            this.btnFragEnd.Text = "Конец";
            this.btnFragEnd.UseVisualStyleBackColor = true;
            this.btnFragEnd.Click += new System.EventHandler(this.btnFragEnd_Click);
            // 
            // edtFragStart
            // 
            this.edtFragStart.Location = new System.Drawing.Point(110, 25);
            this.edtFragStart.Name = "edtFragStart";
            this.edtFragStart.Size = new System.Drawing.Size(61, 20);
            this.edtFragStart.TabIndex = 2;
            this.edtFragStart.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFragStart.ValueChanged += new System.EventHandler(this.edtFragStart_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(0, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Фрагмент:";
            // 
            // btnFragStart
            // 
            this.btnFragStart.Location = new System.Drawing.Point(3, 22);
            this.btnFragStart.Name = "btnFragStart";
            this.btnFragStart.Size = new System.Drawing.Size(90, 23);
            this.btnFragStart.TabIndex = 0;
            this.btnFragStart.Text = "Начало";
            this.btnFragStart.UseVisualStyleBackColor = true;
            this.btnFragStart.Click += new System.EventHandler(this.btnFragStart_Click);
            // 
            // lblFirstFrame
            // 
            this.lblFirstFrame.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblFirstFrame.AutoSize = true;
            this.lblFirstFrame.Location = new System.Drawing.Point(10, 498);
            this.lblFirstFrame.Name = "lblFirstFrame";
            this.lblFirstFrame.Size = new System.Drawing.Size(13, 13);
            this.lblFirstFrame.TabIndex = 11;
            this.lblFirstFrame.Text = "1";
            this.lblFirstFrame.Visible = false;
            // 
            // lblTotalFrames
            // 
            this.lblTotalFrames.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTotalFrames.Location = new System.Drawing.Point(519, 498);
            this.lblTotalFrames.Name = "lblTotalFrames";
            this.lblTotalFrames.Size = new System.Drawing.Size(75, 13);
            this.lblTotalFrames.TabIndex = 12;
            this.lblTotalFrames.Text = "Н/Д";
            this.lblTotalFrames.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblTotalFrames.Visible = false;
            // 
            // lblCurrentFrame
            // 
            this.lblCurrentFrame.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCurrentFrame.Location = new System.Drawing.Point(55, 498);
            this.lblCurrentFrame.Name = "lblCurrentFrame";
            this.lblCurrentFrame.Size = new System.Drawing.Size(458, 13);
            this.lblCurrentFrame.TabIndex = 13;
            this.lblCurrentFrame.Text = "N";
            this.lblCurrentFrame.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblCurrentFrame.Visible = false;
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Title = "Сохранить фрагмент";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.lblCurrentFrame);
            this.Controls.Add(this.lblTotalFrames);
            this.Controls.Add(this.lblFirstFrame);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.trkFrames);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.edtFileName);
            this.Controls.Add(this.lblFile);
            this.Controls.Add(this.pnlCanvas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "frmMain";
            this.Text = "Jinx Frame Viewer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCanvas;
        private System.Windows.Forms.Label lblFile;
        private System.Windows.Forms.TextBox edtFileName;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.TrackBar trkFrames;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown edtWidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown edtHeight;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trkSpeed;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblFirstFrame;
        private System.Windows.Forms.Label lblTotalFrames;
        private System.Windows.Forms.Label lblCurrentFrame;
        private System.Windows.Forms.CheckBox chkGrid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbMatrixType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbColorOrder;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnFragSave;
        private System.Windows.Forms.NumericUpDown edtFragEnd;
        private System.Windows.Forms.Button btnFragEnd;
        private System.Windows.Forms.NumericUpDown edtFragStart;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFragStart;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

