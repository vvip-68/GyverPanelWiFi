﻿namespace JinxFramer
{
    partial class frmMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlCanvas = new System.Windows.Forms.Panel();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.lblFolder = new System.Windows.Forms.Label();
            this.edtFolderName = new System.Windows.Forms.TextBox();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.trkFrames = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.edtWidth = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.edtHeight = new System.Windows.Forms.NumericUpDown();
            this.lblWarning = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlMatrixSize = new System.Windows.Forms.Panel();
            this.pnlMatrixType = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMatrixType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbColorOrder = new System.Windows.Forms.ComboBox();
            this.pnlCut = new System.Windows.Forms.Panel();
            this.chkCutFrame = new System.Windows.Forms.CheckBox();
            this.pnlCutFrame = new System.Windows.Forms.Panel();
            this.edtCutOffsetY = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.edtCutHeight = new System.Windows.Forms.NumericUpDown();
            this.cbCutMatrixType = new System.Windows.Forms.ComboBox();
            this.edtCutOffsetX = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.edtCutWidth = new System.Windows.Forms.NumericUpDown();
            this.cbCutColorOrder = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pnlCutProgress = new System.Windows.Forms.Panel();
            this.progressFrame = new System.Windows.Forms.ProgressBar();
            this.progressFile = new System.Windows.Forms.ProgressBar();
            this.lblFileInProcess = new System.Windows.Forms.Label();
            this.pnlCutButton = new System.Windows.Forms.Panel();
            this.btnStartCut = new System.Windows.Forms.Button();
            this.pnlSpeed = new System.Windows.Forms.Panel();
            this.btnStop = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.trkSpeed = new System.Windows.Forms.TrackBar();
            this.panel7 = new System.Windows.Forms.Panel();
            this.chkGrid = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlFragmentRange = new System.Windows.Forms.Panel();
            this.edtFragEnd = new System.Windows.Forms.NumericUpDown();
            this.btnFragEnd = new System.Windows.Forms.Button();
            this.edtFragStart = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFragStart = new System.Windows.Forms.Button();
            this.pnlFragmentSave = new System.Windows.Forms.Panel();
            this.btnFrameCodeSave = new System.Windows.Forms.Button();
            this.btnFrameSave = new System.Windows.Forms.Button();
            this.btnFragSave = new System.Windows.Forms.Button();
            this.btnFragCodeSave = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.pnlCreate = new System.Windows.Forms.Panel();
            this.rbPicture = new System.Windows.Forms.RadioButton();
            this.rbMovie = new System.Windows.Forms.RadioButton();
            this.btnCreateNew = new System.Windows.Forms.Button();
            this.edtCreateNewFileName = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.edtCreateNewFrames = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlAddFrame = new System.Windows.Forms.Panel();
            this.btnAddFrames = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.edtAddFrames = new System.Windows.Forms.NumericUpDown();
            this.lblFirstFrame = new System.Windows.Forms.Label();
            this.lblTotalFrames = new System.Windows.Forms.Label();
            this.lblCurrentFrame = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.listFiles = new System.Windows.Forms.ListBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cbLanguage = new System.Windows.Forms.ComboBox();
            this.lblLanguageWarning = new System.Windows.Forms.Label();
            this.pnlEditor = new System.Windows.Forms.Panel();
            this.colorPalette = new Cyotek.Windows.Forms.ColorGrid();
            this.btnSetActivePickerBack = new System.Windows.Forms.Button();
            this.btnSetActivePickerFore = new System.Windows.Forms.Button();
            this.screenColorPickerBack = new Cyotek.Windows.Forms.ScreenColorPicker();
            this.btnPaste = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnFill = new System.Windows.Forms.Button();
            this.btnCancelEdit = new System.Windows.Forms.Button();
            this.btnSaveEdit = new System.Windows.Forms.Button();
            this.btnStartEdit = new System.Windows.Forms.Button();
            this.colorEditor = new Cyotek.Windows.Forms.ColorEditor();
            this.screenColorPickerFore = new Cyotek.Windows.Forms.ScreenColorPicker();
            this.colorWheel = new Cyotek.Windows.Forms.ColorWheel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnNextFrame = new System.Windows.Forms.Button();
            this.btnPrevFrame = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlCanvas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.pnlMatrixSize.SuspendLayout();
            this.pnlMatrixType.SuspendLayout();
            this.pnlCut.SuspendLayout();
            this.pnlCutFrame.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutWidth)).BeginInit();
            this.pnlCutProgress.SuspendLayout();
            this.pnlCutButton.SuspendLayout();
            this.pnlSpeed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).BeginInit();
            this.pnlFragmentRange.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).BeginInit();
            this.pnlFragmentSave.SuspendLayout();
            this.pnlCreate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCreateNewFrames)).BeginInit();
            this.pnlAddFrame.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtAddFrames)).BeginInit();
            this.pnlEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCanvas
            // 
            resources.ApplyResources(this.pnlCanvas, "pnlCanvas");
            this.pnlCanvas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCanvas.Controls.Add(this.pictureBox);
            this.pnlCanvas.Name = "pnlCanvas";
            this.pnlCanvas.Resize += new System.EventHandler(this.pnlCanvas_Resize_1);
            // 
            // pictureBox
            // 
            resources.ApplyResources(this.pictureBox, "pictureBox");
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.TabStop = false;
            this.pictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCanvas_Paint);
            this.pictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseClick);
            this.pictureBox.Resize += new System.EventHandler(this.pnlCanvas_Resize);
            // 
            // lblFolder
            // 
            resources.ApplyResources(this.lblFolder, "lblFolder");
            this.lblFolder.Name = "lblFolder";
            // 
            // edtFolderName
            // 
            resources.ApplyResources(this.edtFolderName, "edtFolderName");
            this.edtFolderName.Name = "edtFolderName";
            this.edtFolderName.ReadOnly = true;
            // 
            // btnOpenFile
            // 
            resources.ApplyResources(this.btnOpenFile, "btnOpenFile");
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // trkFrames
            // 
            resources.ApplyResources(this.trkFrames, "trkFrames");
            this.trkFrames.Name = "trkFrames";
            this.trkFrames.ValueChanged += new System.EventHandler(this.trkFrames_ValueChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // edtWidth
            // 
            resources.ApplyResources(this.edtWidth, "edtWidth");
            this.edtWidth.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtWidth.Name = "edtWidth";
            this.edtWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtWidth.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // edtHeight
            // 
            resources.ApplyResources(this.edtHeight, "edtHeight");
            this.edtHeight.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtHeight.Name = "edtHeight";
            this.edtHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtHeight.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // lblWarning
            // 
            resources.ApplyResources(this.lblWarning, "lblWarning");
            this.lblWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblWarning.Name = "lblWarning";
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.Controls.Add(this.label5);
            this.flowLayoutPanel1.Controls.Add(this.pnlMatrixSize);
            this.flowLayoutPanel1.Controls.Add(this.lblWarning);
            this.flowLayoutPanel1.Controls.Add(this.pnlMatrixType);
            this.flowLayoutPanel1.Controls.Add(this.pnlCut);
            this.flowLayoutPanel1.Controls.Add(this.pnlCutProgress);
            this.flowLayoutPanel1.Controls.Add(this.pnlCutButton);
            this.flowLayoutPanel1.Controls.Add(this.pnlSpeed);
            this.flowLayoutPanel1.Controls.Add(this.chkGrid);
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.pnlFragmentRange);
            this.flowLayoutPanel1.Controls.Add(this.pnlFragmentSave);
            this.flowLayoutPanel1.Controls.Add(this.pnlCreate);
            this.flowLayoutPanel1.Controls.Add(this.pnlAddFrame);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // pnlMatrixSize
            // 
            this.pnlMatrixSize.Controls.Add(this.edtHeight);
            this.pnlMatrixSize.Controls.Add(this.label1);
            this.pnlMatrixSize.Controls.Add(this.edtWidth);
            this.pnlMatrixSize.Controls.Add(this.label2);
            this.pnlMatrixSize.Controls.Add(this.btnOpenFile);
            resources.ApplyResources(this.pnlMatrixSize, "pnlMatrixSize");
            this.pnlMatrixSize.Name = "pnlMatrixSize";
            // 
            // pnlMatrixType
            // 
            this.pnlMatrixType.Controls.Add(this.label3);
            this.pnlMatrixType.Controls.Add(this.cbMatrixType);
            this.pnlMatrixType.Controls.Add(this.label6);
            this.pnlMatrixType.Controls.Add(this.cbColorOrder);
            resources.ApplyResources(this.pnlMatrixType, "pnlMatrixType");
            this.pnlMatrixType.Name = "pnlMatrixType";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cbMatrixType
            // 
            this.cbMatrixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMatrixType.FormattingEnabled = true;
            resources.ApplyResources(this.cbMatrixType, "cbMatrixType");
            this.cbMatrixType.Name = "cbMatrixType";
            this.cbMatrixType.SelectedIndexChanged += new System.EventHandler(this.cbMatrixType_SelectedIndexChanged);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // cbColorOrder
            // 
            this.cbColorOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbColorOrder.FormattingEnabled = true;
            this.cbColorOrder.Items.AddRange(new object[] {
            resources.GetString("cbColorOrder.Items"),
            resources.GetString("cbColorOrder.Items1"),
            resources.GetString("cbColorOrder.Items2"),
            resources.GetString("cbColorOrder.Items3"),
            resources.GetString("cbColorOrder.Items4"),
            resources.GetString("cbColorOrder.Items5")});
            resources.ApplyResources(this.cbColorOrder, "cbColorOrder");
            this.cbColorOrder.Name = "cbColorOrder";
            this.cbColorOrder.SelectedIndexChanged += new System.EventHandler(this.cbColorOrder_SelectedIndexChanged);
            // 
            // pnlCut
            // 
            this.pnlCut.Controls.Add(this.chkCutFrame);
            this.pnlCut.Controls.Add(this.pnlCutFrame);
            this.pnlCut.Controls.Add(this.panel6);
            resources.ApplyResources(this.pnlCut, "pnlCut");
            this.pnlCut.Name = "pnlCut";
            // 
            // chkCutFrame
            // 
            resources.ApplyResources(this.chkCutFrame, "chkCutFrame");
            this.chkCutFrame.Name = "chkCutFrame";
            this.chkCutFrame.UseVisualStyleBackColor = true;
            this.chkCutFrame.CheckedChanged += new System.EventHandler(this.chkCutFrame_CheckedChanged);
            // 
            // pnlCutFrame
            // 
            this.pnlCutFrame.Controls.Add(this.edtCutOffsetY);
            this.pnlCutFrame.Controls.Add(this.label10);
            this.pnlCutFrame.Controls.Add(this.edtCutHeight);
            this.pnlCutFrame.Controls.Add(this.cbCutMatrixType);
            this.pnlCutFrame.Controls.Add(this.edtCutOffsetX);
            this.pnlCutFrame.Controls.Add(this.label11);
            this.pnlCutFrame.Controls.Add(this.label12);
            this.pnlCutFrame.Controls.Add(this.label8);
            this.pnlCutFrame.Controls.Add(this.edtCutWidth);
            this.pnlCutFrame.Controls.Add(this.cbCutColorOrder);
            this.pnlCutFrame.Controls.Add(this.label9);
            resources.ApplyResources(this.pnlCutFrame, "pnlCutFrame");
            this.pnlCutFrame.Name = "pnlCutFrame";
            // 
            // edtCutOffsetY
            // 
            resources.ApplyResources(this.edtCutOffsetY, "edtCutOffsetY");
            this.edtCutOffsetY.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtCutOffsetY.Name = "edtCutOffsetY";
            this.edtCutOffsetY.ValueChanged += new System.EventHandler(this.edtCutOffsetY_ValueChanged);
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // edtCutHeight
            // 
            resources.ApplyResources(this.edtCutHeight, "edtCutHeight");
            this.edtCutHeight.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtCutHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtCutHeight.Name = "edtCutHeight";
            this.edtCutHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtCutHeight.ValueChanged += new System.EventHandler(this.edtCutHeight_ValueChanged);
            // 
            // cbCutMatrixType
            // 
            this.cbCutMatrixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCutMatrixType.FormattingEnabled = true;
            resources.ApplyResources(this.cbCutMatrixType, "cbCutMatrixType");
            this.cbCutMatrixType.Name = "cbCutMatrixType";
            this.cbCutMatrixType.SelectedIndexChanged += new System.EventHandler(this.cbCutMatrixType_SelectedIndexChanged);
            // 
            // edtCutOffsetX
            // 
            resources.ApplyResources(this.edtCutOffsetX, "edtCutOffsetX");
            this.edtCutOffsetX.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtCutOffsetX.Name = "edtCutOffsetX";
            this.edtCutOffsetX.ValueChanged += new System.EventHandler(this.edtCutOffsetX_ValueChanged);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // edtCutWidth
            // 
            resources.ApplyResources(this.edtCutWidth, "edtCutWidth");
            this.edtCutWidth.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtCutWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtCutWidth.Name = "edtCutWidth";
            this.edtCutWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtCutWidth.ValueChanged += new System.EventHandler(this.edtCutWidth_ValueChanged);
            // 
            // cbCutColorOrder
            // 
            this.cbCutColorOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCutColorOrder.FormattingEnabled = true;
            this.cbCutColorOrder.Items.AddRange(new object[] {
            resources.GetString("cbCutColorOrder.Items"),
            resources.GetString("cbCutColorOrder.Items1"),
            resources.GetString("cbCutColorOrder.Items2"),
            resources.GetString("cbCutColorOrder.Items3"),
            resources.GetString("cbCutColorOrder.Items4"),
            resources.GetString("cbCutColorOrder.Items5")});
            resources.ApplyResources(this.cbCutColorOrder, "cbCutColorOrder");
            this.cbCutColorOrder.Name = "cbCutColorOrder";
            this.cbCutColorOrder.SelectedIndexChanged += new System.EventHandler(this.cbCutColorOrder_SelectedIndexChanged);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // pnlCutProgress
            // 
            this.pnlCutProgress.Controls.Add(this.progressFrame);
            this.pnlCutProgress.Controls.Add(this.progressFile);
            this.pnlCutProgress.Controls.Add(this.lblFileInProcess);
            resources.ApplyResources(this.pnlCutProgress, "pnlCutProgress");
            this.pnlCutProgress.Name = "pnlCutProgress";
            // 
            // progressFrame
            // 
            resources.ApplyResources(this.progressFrame, "progressFrame");
            this.progressFrame.Name = "progressFrame";
            this.progressFrame.Step = 1;
            this.progressFrame.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressFrame.Value = 1;
            // 
            // progressFile
            // 
            resources.ApplyResources(this.progressFile, "progressFile");
            this.progressFile.Name = "progressFile";
            this.progressFile.Step = 1;
            this.progressFile.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressFile.Value = 1;
            // 
            // lblFileInProcess
            // 
            this.lblFileInProcess.AutoEllipsis = true;
            resources.ApplyResources(this.lblFileInProcess, "lblFileInProcess");
            this.lblFileInProcess.Name = "lblFileInProcess";
            // 
            // pnlCutButton
            // 
            this.pnlCutButton.Controls.Add(this.btnStartCut);
            resources.ApplyResources(this.pnlCutButton, "pnlCutButton");
            this.pnlCutButton.Name = "pnlCutButton";
            // 
            // btnStartCut
            // 
            resources.ApplyResources(this.btnStartCut, "btnStartCut");
            this.btnStartCut.Name = "btnStartCut";
            this.btnStartCut.UseVisualStyleBackColor = true;
            this.btnStartCut.Click += new System.EventHandler(this.btnStartCut_Click);
            // 
            // pnlSpeed
            // 
            this.pnlSpeed.Controls.Add(this.btnStop);
            this.pnlSpeed.Controls.Add(this.label4);
            this.pnlSpeed.Controls.Add(this.btnStart);
            this.pnlSpeed.Controls.Add(this.trkSpeed);
            this.pnlSpeed.Controls.Add(this.panel7);
            resources.ApplyResources(this.pnlSpeed, "pnlSpeed");
            this.pnlSpeed.Name = "pnlSpeed";
            // 
            // btnStop
            // 
            resources.ApplyResources(this.btnStop, "btnStop");
            this.btnStop.Name = "btnStop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // btnStart
            // 
            resources.ApplyResources(this.btnStart, "btnStart");
            this.btnStart.Image = global::JinxFramer.Properties.Resources.play;
            this.btnStart.Name = "btnStart";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // trkSpeed
            // 
            resources.ApplyResources(this.trkSpeed, "trkSpeed");
            this.trkSpeed.Maximum = 100;
            this.trkSpeed.Minimum = 1;
            this.trkSpeed.Name = "trkSpeed";
            this.trkSpeed.Value = 10;
            this.trkSpeed.ValueChanged += new System.EventHandler(this.trkSpeed_ValueChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // chkGrid
            // 
            resources.ApplyResources(this.chkGrid, "chkGrid");
            this.chkGrid.Checked = true;
            this.chkGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkGrid.Name = "chkGrid";
            this.chkGrid.UseVisualStyleBackColor = true;
            this.chkGrid.CheckedChanged += new System.EventHandler(this.chkGrid_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // pnlFragmentRange
            // 
            this.pnlFragmentRange.Controls.Add(this.edtFragEnd);
            this.pnlFragmentRange.Controls.Add(this.btnFragEnd);
            this.pnlFragmentRange.Controls.Add(this.edtFragStart);
            this.pnlFragmentRange.Controls.Add(this.label7);
            this.pnlFragmentRange.Controls.Add(this.btnFragStart);
            resources.ApplyResources(this.pnlFragmentRange, "pnlFragmentRange");
            this.pnlFragmentRange.Name = "pnlFragmentRange";
            // 
            // edtFragEnd
            // 
            resources.ApplyResources(this.edtFragEnd, "edtFragEnd");
            this.edtFragEnd.Name = "edtFragEnd";
            this.edtFragEnd.ValueChanged += new System.EventHandler(this.edtFragEnd_ValueChanged);
            // 
            // btnFragEnd
            // 
            resources.ApplyResources(this.btnFragEnd, "btnFragEnd");
            this.btnFragEnd.Name = "btnFragEnd";
            this.btnFragEnd.UseVisualStyleBackColor = true;
            this.btnFragEnd.Click += new System.EventHandler(this.btnFragEnd_Click);
            // 
            // edtFragStart
            // 
            resources.ApplyResources(this.edtFragStart, "edtFragStart");
            this.edtFragStart.Name = "edtFragStart";
            this.edtFragStart.ValueChanged += new System.EventHandler(this.edtFragStart_ValueChanged);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // btnFragStart
            // 
            resources.ApplyResources(this.btnFragStart, "btnFragStart");
            this.btnFragStart.Name = "btnFragStart";
            this.btnFragStart.UseVisualStyleBackColor = true;
            this.btnFragStart.Click += new System.EventHandler(this.btnFragStart_Click);
            // 
            // pnlFragmentSave
            // 
            this.pnlFragmentSave.Controls.Add(this.btnFrameCodeSave);
            this.pnlFragmentSave.Controls.Add(this.btnFrameSave);
            this.pnlFragmentSave.Controls.Add(this.btnFragSave);
            this.pnlFragmentSave.Controls.Add(this.btnFragCodeSave);
            this.pnlFragmentSave.Controls.Add(this.label15);
            resources.ApplyResources(this.pnlFragmentSave, "pnlFragmentSave");
            this.pnlFragmentSave.Name = "pnlFragmentSave";
            // 
            // btnFrameCodeSave
            // 
            resources.ApplyResources(this.btnFrameCodeSave, "btnFrameCodeSave");
            this.btnFrameCodeSave.Name = "btnFrameCodeSave";
            this.btnFrameCodeSave.UseVisualStyleBackColor = true;
            this.btnFrameCodeSave.Click += new System.EventHandler(this.btnFrameCodeSave_Click);
            // 
            // btnFrameSave
            // 
            resources.ApplyResources(this.btnFrameSave, "btnFrameSave");
            this.btnFrameSave.Name = "btnFrameSave";
            this.btnFrameSave.UseVisualStyleBackColor = true;
            this.btnFrameSave.Click += new System.EventHandler(this.btnFrameSave_Click);
            // 
            // btnFragSave
            // 
            resources.ApplyResources(this.btnFragSave, "btnFragSave");
            this.btnFragSave.Name = "btnFragSave";
            this.btnFragSave.UseVisualStyleBackColor = true;
            this.btnFragSave.Click += new System.EventHandler(this.btnFragSave_Click);
            // 
            // btnFragCodeSave
            // 
            resources.ApplyResources(this.btnFragCodeSave, "btnFragCodeSave");
            this.btnFragCodeSave.Name = "btnFragCodeSave";
            this.btnFragCodeSave.UseVisualStyleBackColor = true;
            this.btnFragCodeSave.Click += new System.EventHandler(this.btnFragCodeSave_Click);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // pnlCreate
            // 
            this.pnlCreate.Controls.Add(this.rbPicture);
            this.pnlCreate.Controls.Add(this.rbMovie);
            this.pnlCreate.Controls.Add(this.btnCreateNew);
            this.pnlCreate.Controls.Add(this.edtCreateNewFileName);
            this.pnlCreate.Controls.Add(this.label17);
            this.pnlCreate.Controls.Add(this.label16);
            this.pnlCreate.Controls.Add(this.edtCreateNewFrames);
            this.pnlCreate.Controls.Add(this.label20);
            this.pnlCreate.Controls.Add(this.panel2);
            resources.ApplyResources(this.pnlCreate, "pnlCreate");
            this.pnlCreate.Name = "pnlCreate";
            // 
            // rbPicture
            // 
            resources.ApplyResources(this.rbPicture, "rbPicture");
            this.rbPicture.Name = "rbPicture";
            this.rbPicture.UseVisualStyleBackColor = true;
            // 
            // rbMovie
            // 
            resources.ApplyResources(this.rbMovie, "rbMovie");
            this.rbMovie.Checked = true;
            this.rbMovie.Name = "rbMovie";
            this.rbMovie.TabStop = true;
            this.rbMovie.UseVisualStyleBackColor = true;
            // 
            // btnCreateNew
            // 
            resources.ApplyResources(this.btnCreateNew, "btnCreateNew");
            this.btnCreateNew.Name = "btnCreateNew";
            this.btnCreateNew.UseVisualStyleBackColor = true;
            this.btnCreateNew.Click += new System.EventHandler(this.btnCreateNew_Click);
            // 
            // edtCreateNewFileName
            // 
            resources.ApplyResources(this.edtCreateNewFileName, "edtCreateNewFileName");
            this.edtCreateNewFileName.Name = "edtCreateNewFileName";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // edtCreateNewFrames
            // 
            resources.ApplyResources(this.edtCreateNewFrames, "edtCreateNewFrames");
            this.edtCreateNewFrames.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.edtCreateNewFrames.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtCreateNewFrames.Name = "edtCreateNewFrames";
            this.edtCreateNewFrames.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // pnlAddFrame
            // 
            this.pnlAddFrame.Controls.Add(this.btnAddFrames);
            this.pnlAddFrame.Controls.Add(this.panel13);
            this.pnlAddFrame.Controls.Add(this.label19);
            this.pnlAddFrame.Controls.Add(this.label18);
            this.pnlAddFrame.Controls.Add(this.edtAddFrames);
            resources.ApplyResources(this.pnlAddFrame, "pnlAddFrame");
            this.pnlAddFrame.Name = "pnlAddFrame";
            // 
            // btnAddFrames
            // 
            resources.ApplyResources(this.btnAddFrames, "btnAddFrames");
            this.btnAddFrames.Name = "btnAddFrames";
            this.btnAddFrames.UseVisualStyleBackColor = true;
            this.btnAddFrames.Click += new System.EventHandler(this.btmAddFrames_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.Name = "panel13";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // edtAddFrames
            // 
            resources.ApplyResources(this.edtAddFrames, "edtAddFrames");
            this.edtAddFrames.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtAddFrames.Name = "edtAddFrames";
            this.edtAddFrames.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblFirstFrame
            // 
            resources.ApplyResources(this.lblFirstFrame, "lblFirstFrame");
            this.lblFirstFrame.Name = "lblFirstFrame";
            // 
            // lblTotalFrames
            // 
            resources.ApplyResources(this.lblTotalFrames, "lblTotalFrames");
            this.lblTotalFrames.Name = "lblTotalFrames";
            // 
            // lblCurrentFrame
            // 
            resources.ApplyResources(this.lblCurrentFrame, "lblCurrentFrame");
            this.lblCurrentFrame.Name = "lblCurrentFrame";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.OverwritePrompt = false;
            resources.ApplyResources(this.saveFileDialog, "saveFileDialog");
            // 
            // listFiles
            // 
            resources.ApplyResources(this.listFiles, "listFiles");
            this.listFiles.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listFiles.FormattingEnabled = true;
            this.listFiles.Name = "listFiles";
            this.listFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listFiles.Sorted = true;
            this.listFiles.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listFiles_DrawItem);
            this.listFiles.SelectedIndexChanged += new System.EventHandler(this.listFiles_SelectedIndexChanged);
            this.listFiles.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listFiles_MouseDoubleClick);
            // 
            // lblVersion
            // 
            resources.ApplyResources(this.lblVersion, "lblVersion");
            this.lblVersion.Name = "lblVersion";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // cbLanguage
            // 
            resources.ApplyResources(this.cbLanguage, "cbLanguage");
            this.cbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLanguage.FormattingEnabled = true;
            this.cbLanguage.Name = "cbLanguage";
            this.cbLanguage.SelectedIndexChanged += new System.EventHandler(this.cbLanguage_SelectedIndexChanged);
            // 
            // lblLanguageWarning
            // 
            resources.ApplyResources(this.lblLanguageWarning, "lblLanguageWarning");
            this.lblLanguageWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblLanguageWarning.Name = "lblLanguageWarning";
            // 
            // pnlEditor
            // 
            resources.ApplyResources(this.pnlEditor, "pnlEditor");
            this.pnlEditor.Controls.Add(this.colorPalette);
            this.pnlEditor.Controls.Add(this.btnSetActivePickerBack);
            this.pnlEditor.Controls.Add(this.btnSetActivePickerFore);
            this.pnlEditor.Controls.Add(this.screenColorPickerBack);
            this.pnlEditor.Controls.Add(this.btnPaste);
            this.pnlEditor.Controls.Add(this.btnCopy);
            this.pnlEditor.Controls.Add(this.btnFill);
            this.pnlEditor.Controls.Add(this.btnCancelEdit);
            this.pnlEditor.Controls.Add(this.btnSaveEdit);
            this.pnlEditor.Controls.Add(this.btnStartEdit);
            this.pnlEditor.Controls.Add(this.colorEditor);
            this.pnlEditor.Controls.Add(this.screenColorPickerFore);
            this.pnlEditor.Controls.Add(this.colorWheel);
            this.pnlEditor.Name = "pnlEditor";
            // 
            // colorPalette
            // 
            this.colorPalette.AutoAddColors = false;
            resources.ApplyResources(this.colorPalette, "colorPalette");
            this.colorPalette.CellBorderStyle = Cyotek.Windows.Forms.ColorCellBorderStyle.None;
            this.colorPalette.Columns = 8;
            this.colorPalette.Name = "colorPalette";
            this.colorPalette.Palette = Cyotek.Windows.Forms.ColorPalette.Standard;
            this.colorPalette.SelectedCellStyle = Cyotek.Windows.Forms.ColorGridSelectedCellStyle.None;
            this.colorPalette.ShowToolTips = false;
            this.colorPalette.Spacing = new System.Drawing.Size(1, 1);
            this.colorPalette.MouseUp += new System.Windows.Forms.MouseEventHandler(this.colorPalette_MouseUp);
            // 
            // btnSetActivePickerBack
            // 
            resources.ApplyResources(this.btnSetActivePickerBack, "btnSetActivePickerBack");
            this.btnSetActivePickerBack.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnSetActivePickerBack.Name = "btnSetActivePickerBack";
            this.btnSetActivePickerBack.TabStop = false;
            this.btnSetActivePickerBack.Tag = "0";
            this.btnSetActivePickerBack.UseVisualStyleBackColor = true;
            this.btnSetActivePickerBack.Click += new System.EventHandler(this.btnSetActivePickerFore_Click);
            // 
            // btnSetActivePickerFore
            // 
            resources.ApplyResources(this.btnSetActivePickerFore, "btnSetActivePickerFore");
            this.btnSetActivePickerFore.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnSetActivePickerFore.Name = "btnSetActivePickerFore";
            this.btnSetActivePickerFore.TabStop = false;
            this.btnSetActivePickerFore.Tag = "0";
            this.btnSetActivePickerFore.UseVisualStyleBackColor = true;
            this.btnSetActivePickerFore.Click += new System.EventHandler(this.btnSetActivePickerFore_Click);
            // 
            // screenColorPickerBack
            // 
            this.screenColorPickerBack.Color = System.Drawing.Color.Empty;
            resources.ApplyResources(this.screenColorPickerBack, "screenColorPickerBack");
            this.screenColorPickerBack.Image = global::JinxFramer.Properties.Resources.pipette;
            this.screenColorPickerBack.Name = "screenColorPickerBack";
            this.screenColorPickerBack.ShowTextWithSnapshot = true;
            this.screenColorPickerBack.Zoom = 10;
            this.screenColorPickerBack.ColorChanged += new System.EventHandler(this.screenColorPicker_ColorChanged);
            this.screenColorPickerBack.MouseDown += new System.Windows.Forms.MouseEventHandler(this.screenColorPickerFore_MouseDown);
            this.screenColorPickerBack.MouseUp += new System.Windows.Forms.MouseEventHandler(this.screenColorPicker_MouseUp);
            // 
            // btnPaste
            // 
            resources.ApplyResources(this.btnPaste, "btnPaste");
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.UseVisualStyleBackColor = true;
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // btnCopy
            // 
            resources.ApplyResources(this.btnCopy, "btnCopy");
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnFill
            // 
            resources.ApplyResources(this.btnFill, "btnFill");
            this.btnFill.Name = "btnFill";
            this.btnFill.UseVisualStyleBackColor = true;
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);
            // 
            // btnCancelEdit
            // 
            resources.ApplyResources(this.btnCancelEdit, "btnCancelEdit");
            this.btnCancelEdit.Name = "btnCancelEdit";
            this.btnCancelEdit.UseVisualStyleBackColor = true;
            this.btnCancelEdit.Click += new System.EventHandler(this.btnCancelEdit_Click);
            // 
            // btnSaveEdit
            // 
            resources.ApplyResources(this.btnSaveEdit, "btnSaveEdit");
            this.btnSaveEdit.Name = "btnSaveEdit";
            this.btnSaveEdit.UseVisualStyleBackColor = true;
            this.btnSaveEdit.Click += new System.EventHandler(this.btnSaveEdit_Click);
            // 
            // btnStartEdit
            // 
            resources.ApplyResources(this.btnStartEdit, "btnStartEdit");
            this.btnStartEdit.Name = "btnStartEdit";
            this.btnStartEdit.UseVisualStyleBackColor = true;
            this.btnStartEdit.Click += new System.EventHandler(this.btnStartEdit_Click);
            // 
            // colorEditor
            // 
            resources.ApplyResources(this.colorEditor, "colorEditor");
            this.colorEditor.Name = "colorEditor";
            this.colorEditor.ShowAlphaChannel = false;
            this.colorEditor.ShowColorSpaceLabels = false;
            this.colorEditor.ColorChanged += new System.EventHandler(this.colorEditor_ColorChanged);
            // 
            // screenColorPickerFore
            // 
            this.screenColorPickerFore.Color = System.Drawing.Color.Empty;
            resources.ApplyResources(this.screenColorPickerFore, "screenColorPickerFore");
            this.screenColorPickerFore.Image = global::JinxFramer.Properties.Resources.pipette;
            this.screenColorPickerFore.Name = "screenColorPickerFore";
            this.screenColorPickerFore.ShowTextWithSnapshot = true;
            this.screenColorPickerFore.Zoom = 10;
            this.screenColorPickerFore.ColorChanged += new System.EventHandler(this.screenColorPicker_ColorChanged);
            this.screenColorPickerFore.MouseDown += new System.Windows.Forms.MouseEventHandler(this.screenColorPickerFore_MouseDown);
            this.screenColorPickerFore.MouseUp += new System.Windows.Forms.MouseEventHandler(this.screenColorPicker_MouseUp);
            // 
            // colorWheel
            // 
            resources.ApplyResources(this.colorWheel, "colorWheel");
            this.colorWheel.Name = "colorWheel";
            this.colorWheel.ColorChanged += new System.EventHandler(this.colorWheel_ColorChanged);
            // 
            // panel11
            // 
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel11.Name = "panel11";
            // 
            // btnNextFrame
            // 
            this.btnNextFrame.Image = global::JinxFramer.Properties.Resources.arrow_000_medium;
            resources.ApplyResources(this.btnNextFrame, "btnNextFrame");
            this.btnNextFrame.Name = "btnNextFrame";
            this.btnNextFrame.UseVisualStyleBackColor = true;
            this.btnNextFrame.Click += new System.EventHandler(this.btnNextFrame_Click);
            // 
            // btnPrevFrame
            // 
            this.btnPrevFrame.Image = global::JinxFramer.Properties.Resources.arrow_180_medium;
            resources.ApplyResources(this.btnPrevFrame, "btnPrevFrame");
            this.btnPrevFrame.Name = "btnPrevFrame";
            this.btnPrevFrame.UseVisualStyleBackColor = true;
            this.btnPrevFrame.Click += new System.EventHandler(this.btnPrevFrame_Click);
            // 
            // btnDelete
            // 
            resources.ApplyResources(this.btnDelete, "btnDelete");
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnNextFrame);
            this.Controls.Add(this.btnPrevFrame);
            this.Controls.Add(this.pnlEditor);
            this.Controls.Add(this.lblLanguageWarning);
            this.Controls.Add(this.cbLanguage);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.listFiles);
            this.Controls.Add(this.lblCurrentFrame);
            this.Controls.Add(this.lblTotalFrames);
            this.Controls.Add(this.lblFirstFrame);
            this.Controls.Add(this.trkFrames);
            this.Controls.Add(this.edtFolderName);
            this.Controls.Add(this.lblFolder);
            this.Controls.Add(this.pnlCanvas);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.pnlCanvas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.pnlMatrixSize.ResumeLayout(false);
            this.pnlMatrixSize.PerformLayout();
            this.pnlMatrixType.ResumeLayout(false);
            this.pnlMatrixType.PerformLayout();
            this.pnlCut.ResumeLayout(false);
            this.pnlCut.PerformLayout();
            this.pnlCutFrame.ResumeLayout(false);
            this.pnlCutFrame.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutWidth)).EndInit();
            this.pnlCutProgress.ResumeLayout(false);
            this.pnlCutButton.ResumeLayout(false);
            this.pnlSpeed.ResumeLayout(false);
            this.pnlSpeed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).EndInit();
            this.pnlFragmentRange.ResumeLayout(false);
            this.pnlFragmentRange.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).EndInit();
            this.pnlFragmentSave.ResumeLayout(false);
            this.pnlFragmentSave.PerformLayout();
            this.pnlCreate.ResumeLayout(false);
            this.pnlCreate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCreateNewFrames)).EndInit();
            this.pnlAddFrame.ResumeLayout(false);
            this.pnlAddFrame.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtAddFrames)).EndInit();
            this.pnlEditor.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCanvas;
        private System.Windows.Forms.Label lblFolder;
        private System.Windows.Forms.TextBox edtFolderName;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.TrackBar trkFrames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown edtWidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown edtHeight;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlMatrixSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trkSpeed;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblFirstFrame;
        private System.Windows.Forms.Label lblTotalFrames;
        private System.Windows.Forms.Label lblCurrentFrame;
        private System.Windows.Forms.CheckBox chkGrid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbMatrixType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbColorOrder;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnlFragmentRange;
        private System.Windows.Forms.Button btnFragSave;
        private System.Windows.Forms.NumericUpDown edtFragEnd;
        private System.Windows.Forms.Button btnFragEnd;
        private System.Windows.Forms.NumericUpDown edtFragStart;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFragStart;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ListBox listFiles;
        private System.Windows.Forms.CheckBox chkCutFrame;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbCutMatrixType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbCutColorOrder;
        private System.Windows.Forms.Panel pnlCutFrame;
        private System.Windows.Forms.NumericUpDown edtCutHeight;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown edtCutWidth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnStartCut;
        private System.Windows.Forms.Panel pnlFragmentSave;
        private System.Windows.Forms.NumericUpDown edtCutOffsetY;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown edtCutOffsetX;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Panel pnlCutProgress;
        private System.Windows.Forms.ProgressBar progressFrame;
        private System.Windows.Forms.ProgressBar progressFile;
        private System.Windows.Forms.Label lblFileInProcess;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbLanguage;
        private System.Windows.Forms.Label lblLanguageWarning;
        private System.Windows.Forms.Panel pnlMatrixType;
        private System.Windows.Forms.Panel pnlSpeed;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnFrameCodeSave;
        private System.Windows.Forms.Button btnFrameSave;
        private System.Windows.Forms.Button btnFragCodeSave;
        private System.Windows.Forms.Panel pnlEditor;
        private System.Windows.Forms.Panel panel11;
        private Cyotek.Windows.Forms.ScreenColorPicker screenColorPickerFore;
        private Cyotek.Windows.Forms.ColorWheel colorWheel;
        private Cyotek.Windows.Forms.ColorEditor colorEditor;
        private System.Windows.Forms.Button btnCancelEdit;
        private System.Windows.Forms.Button btnSaveEdit;
        private System.Windows.Forms.Button btnStartEdit;
        private System.Windows.Forms.Button btnPrevFrame;
        private System.Windows.Forms.Button btnNextFrame;
        private System.Windows.Forms.Button btnFill;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlCreate;
        private System.Windows.Forms.Button btnAddFrames;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown edtAddFrames;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button btnCreateNew;
        private System.Windows.Forms.TextBox edtCreateNewFileName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown edtCreateNewFrames;
        private System.Windows.Forms.Button btnPaste;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Panel pnlCut;
        private System.Windows.Forms.RadioButton rbPicture;
        private System.Windows.Forms.RadioButton rbMovie;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel pnlAddFrame;
        private System.Windows.Forms.Panel pnlCutButton;
        private System.Windows.Forms.Button btnDelete;
        private Cyotek.Windows.Forms.ScreenColorPicker screenColorPickerBack;
        private System.Windows.Forms.Button btnSetActivePickerBack;
        private System.Windows.Forms.Button btnSetActivePickerFore;
        private Cyotek.Windows.Forms.ColorGrid colorPalette;
    }
}

