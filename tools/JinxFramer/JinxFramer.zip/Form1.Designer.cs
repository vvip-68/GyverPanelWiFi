﻿namespace JinxFramer
{
    partial class frmMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlCanvas = new System.Windows.Forms.Panel();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.lblFolder = new System.Windows.Forms.Label();
            this.edtFolderName = new System.Windows.Forms.TextBox();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.trkFrames = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.edtWidth = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.edtHeight = new System.Windows.Forms.NumericUpDown();
            this.lblWarning = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMatrixType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbColorOrder = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.chkCutFrame = new System.Windows.Forms.CheckBox();
            this.pnlCutFrame = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.edtCutOffsetY = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.edtCutOffsetX = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbCutMatrixType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbCutColorOrder = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.edtCutHeight = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.edtCutWidth = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.pnlCutProgress = new System.Windows.Forms.Panel();
            this.progressFrame = new System.Windows.Forms.ProgressBar();
            this.progressFile = new System.Windows.Forms.ProgressBar();
            this.lblFileInProcess = new System.Windows.Forms.Label();
            this.btnStartCut = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.trkSpeed = new System.Windows.Forms.TrackBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.chkGrid = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnFragSave = new System.Windows.Forms.Button();
            this.edtFragEnd = new System.Windows.Forms.NumericUpDown();
            this.btnFragEnd = new System.Windows.Forms.Button();
            this.edtFragStart = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFragStart = new System.Windows.Forms.Button();
            this.lblFirstFrame = new System.Windows.Forms.Label();
            this.lblTotalFrames = new System.Windows.Forms.Label();
            this.lblCurrentFrame = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.listFiles = new System.Windows.Forms.ListBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cbLanguage = new System.Windows.Forms.ComboBox();
            this.lblLanguageWarning = new System.Windows.Forms.Label();
            this.pnlCanvas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlCutFrame.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetX)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutWidth)).BeginInit();
            this.pnlCutProgress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCanvas
            // 
            resources.ApplyResources(this.pnlCanvas, "pnlCanvas");
            this.pnlCanvas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCanvas.Controls.Add(this.pictureBox);
            this.pnlCanvas.Name = "pnlCanvas";
            this.pnlCanvas.Resize += new System.EventHandler(this.pnlCanvas_Resize_1);
            // 
            // pictureBox
            // 
            resources.ApplyResources(this.pictureBox, "pictureBox");
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.TabStop = false;
            this.pictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCanvas_Paint);
            this.pictureBox.Resize += new System.EventHandler(this.pnlCanvas_Resize);
            // 
            // lblFolder
            // 
            resources.ApplyResources(this.lblFolder, "lblFolder");
            this.lblFolder.Name = "lblFolder";
            // 
            // edtFolderName
            // 
            resources.ApplyResources(this.edtFolderName, "edtFolderName");
            this.edtFolderName.Name = "edtFolderName";
            this.edtFolderName.ReadOnly = true;
            // 
            // btnOpenFile
            // 
            resources.ApplyResources(this.btnOpenFile, "btnOpenFile");
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // trkFrames
            // 
            resources.ApplyResources(this.trkFrames, "trkFrames");
            this.trkFrames.Name = "trkFrames";
            this.trkFrames.ValueChanged += new System.EventHandler(this.trkFrames_ValueChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // edtWidth
            // 
            resources.ApplyResources(this.edtWidth, "edtWidth");
            this.edtWidth.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtWidth.Name = "edtWidth";
            this.edtWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtWidth.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // edtHeight
            // 
            resources.ApplyResources(this.edtHeight, "edtHeight");
            this.edtHeight.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtHeight.Name = "edtHeight";
            this.edtHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtHeight.ValueChanged += new System.EventHandler(this.Dims_ValueChanged);
            // 
            // lblWarning
            // 
            resources.ApplyResources(this.lblWarning, "lblWarning");
            this.lblWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblWarning.Name = "lblWarning";
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.Controls.Add(this.label5);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.lblWarning);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.cbMatrixType);
            this.flowLayoutPanel1.Controls.Add(this.label6);
            this.flowLayoutPanel1.Controls.Add(this.cbColorOrder);
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.chkCutFrame);
            this.flowLayoutPanel1.Controls.Add(this.pnlCutFrame);
            this.flowLayoutPanel1.Controls.Add(this.pnlCutProgress);
            this.flowLayoutPanel1.Controls.Add(this.btnStartCut);
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Controls.Add(this.label4);
            this.flowLayoutPanel1.Controls.Add(this.trkSpeed);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.chkGrid);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.edtHeight);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.edtWidth);
            this.panel1.Controls.Add(this.label2);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cbMatrixType
            // 
            this.cbMatrixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMatrixType.FormattingEnabled = true;
            resources.ApplyResources(this.cbMatrixType, "cbMatrixType");
            this.cbMatrixType.Name = "cbMatrixType";
            this.cbMatrixType.SelectedIndexChanged += new System.EventHandler(this.cbMatrixType_SelectedIndexChanged);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // cbColorOrder
            // 
            this.cbColorOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbColorOrder.FormattingEnabled = true;
            this.cbColorOrder.Items.AddRange(new object[] {
            resources.GetString("cbColorOrder.Items"),
            resources.GetString("cbColorOrder.Items1"),
            resources.GetString("cbColorOrder.Items2"),
            resources.GetString("cbColorOrder.Items3"),
            resources.GetString("cbColorOrder.Items4"),
            resources.GetString("cbColorOrder.Items5")});
            resources.ApplyResources(this.cbColorOrder, "cbColorOrder");
            this.cbColorOrder.Name = "cbColorOrder";
            this.cbColorOrder.SelectedIndexChanged += new System.EventHandler(this.cbColorOrder_SelectedIndexChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // chkCutFrame
            // 
            resources.ApplyResources(this.chkCutFrame, "chkCutFrame");
            this.chkCutFrame.Name = "chkCutFrame";
            this.chkCutFrame.UseVisualStyleBackColor = true;
            this.chkCutFrame.CheckedChanged += new System.EventHandler(this.chkCutFrame_CheckedChanged);
            // 
            // pnlCutFrame
            // 
            this.pnlCutFrame.Controls.Add(this.panel8);
            this.pnlCutFrame.Controls.Add(this.label10);
            this.pnlCutFrame.Controls.Add(this.cbCutMatrixType);
            this.pnlCutFrame.Controls.Add(this.label11);
            this.pnlCutFrame.Controls.Add(this.cbCutColorOrder);
            this.pnlCutFrame.Controls.Add(this.panel5);
            resources.ApplyResources(this.pnlCutFrame, "pnlCutFrame");
            this.pnlCutFrame.Name = "pnlCutFrame";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.edtCutOffsetY);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.edtCutOffsetX);
            this.panel8.Controls.Add(this.label13);
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // edtCutOffsetY
            // 
            resources.ApplyResources(this.edtCutOffsetY, "edtCutOffsetY");
            this.edtCutOffsetY.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtCutOffsetY.Name = "edtCutOffsetY";
            this.edtCutOffsetY.ValueChanged += new System.EventHandler(this.edtCutOffsetY_ValueChanged);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // edtCutOffsetX
            // 
            resources.ApplyResources(this.edtCutOffsetX, "edtCutOffsetX");
            this.edtCutOffsetX.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.edtCutOffsetX.Name = "edtCutOffsetX";
            this.edtCutOffsetX.ValueChanged += new System.EventHandler(this.edtCutOffsetX_ValueChanged);
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // cbCutMatrixType
            // 
            this.cbCutMatrixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCutMatrixType.FormattingEnabled = true;
            resources.ApplyResources(this.cbCutMatrixType, "cbCutMatrixType");
            this.cbCutMatrixType.Name = "cbCutMatrixType";
            this.cbCutMatrixType.SelectedIndexChanged += new System.EventHandler(this.cbCutMatrixType_SelectedIndexChanged);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // cbCutColorOrder
            // 
            this.cbCutColorOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCutColorOrder.FormattingEnabled = true;
            this.cbCutColorOrder.Items.AddRange(new object[] {
            resources.GetString("cbCutColorOrder.Items"),
            resources.GetString("cbCutColorOrder.Items1"),
            resources.GetString("cbCutColorOrder.Items2"),
            resources.GetString("cbCutColorOrder.Items3"),
            resources.GetString("cbCutColorOrder.Items4"),
            resources.GetString("cbCutColorOrder.Items5")});
            resources.ApplyResources(this.cbCutColorOrder, "cbCutColorOrder");
            this.cbCutColorOrder.Name = "cbCutColorOrder";
            this.cbCutColorOrder.SelectedIndexChanged += new System.EventHandler(this.cbCutColorOrder_SelectedIndexChanged);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.edtCutHeight);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.edtCutWidth);
            this.panel5.Controls.Add(this.label9);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // edtCutHeight
            // 
            resources.ApplyResources(this.edtCutHeight, "edtCutHeight");
            this.edtCutHeight.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtCutHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtCutHeight.Name = "edtCutHeight";
            this.edtCutHeight.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtCutHeight.ValueChanged += new System.EventHandler(this.edtCutHeight_ValueChanged);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // edtCutWidth
            // 
            resources.ApplyResources(this.edtCutWidth, "edtCutWidth");
            this.edtCutWidth.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.edtCutWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.edtCutWidth.Name = "edtCutWidth";
            this.edtCutWidth.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtCutWidth.ValueChanged += new System.EventHandler(this.edtCutWidth_ValueChanged);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // pnlCutProgress
            // 
            this.pnlCutProgress.Controls.Add(this.progressFrame);
            this.pnlCutProgress.Controls.Add(this.progressFile);
            this.pnlCutProgress.Controls.Add(this.lblFileInProcess);
            resources.ApplyResources(this.pnlCutProgress, "pnlCutProgress");
            this.pnlCutProgress.Name = "pnlCutProgress";
            // 
            // progressFrame
            // 
            resources.ApplyResources(this.progressFrame, "progressFrame");
            this.progressFrame.Name = "progressFrame";
            this.progressFrame.Step = 1;
            this.progressFrame.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressFrame.Value = 1;
            // 
            // progressFile
            // 
            resources.ApplyResources(this.progressFile, "progressFile");
            this.progressFile.Name = "progressFile";
            this.progressFile.Step = 1;
            this.progressFile.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressFile.Value = 1;
            // 
            // lblFileInProcess
            // 
            this.lblFileInProcess.AutoEllipsis = true;
            resources.ApplyResources(this.lblFileInProcess, "lblFileInProcess");
            this.lblFileInProcess.Name = "lblFileInProcess";
            // 
            // btnStartCut
            // 
            resources.ApplyResources(this.btnStartCut, "btnStartCut");
            this.btnStartCut.Name = "btnStartCut";
            this.btnStartCut.UseVisualStyleBackColor = true;
            this.btnStartCut.Click += new System.EventHandler(this.btnStartCut_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // trkSpeed
            // 
            resources.ApplyResources(this.trkSpeed, "trkSpeed");
            this.trkSpeed.Maximum = 100;
            this.trkSpeed.Minimum = 1;
            this.trkSpeed.Name = "trkSpeed";
            this.trkSpeed.Value = 10;
            this.trkSpeed.ValueChanged += new System.EventHandler(this.trkSpeed_ValueChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnStop);
            this.panel2.Controls.Add(this.btnStart);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // btnStop
            // 
            resources.ApplyResources(this.btnStop, "btnStop");
            this.btnStop.Name = "btnStop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            resources.ApplyResources(this.btnStart, "btnStart");
            this.btnStart.Image = global::JinxFramer.Properties.Resources.play;
            this.btnStart.Name = "btnStart";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // chkGrid
            // 
            resources.ApplyResources(this.chkGrid, "chkGrid");
            this.chkGrid.Checked = true;
            this.chkGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkGrid.Name = "chkGrid";
            this.chkGrid.UseVisualStyleBackColor = true;
            this.chkGrid.CheckedChanged += new System.EventHandler(this.chkGrid_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnFragSave);
            this.panel4.Controls.Add(this.edtFragEnd);
            this.panel4.Controls.Add(this.btnFragEnd);
            this.panel4.Controls.Add(this.edtFragStart);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.btnFragStart);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // btnFragSave
            // 
            resources.ApplyResources(this.btnFragSave, "btnFragSave");
            this.btnFragSave.Name = "btnFragSave";
            this.btnFragSave.UseVisualStyleBackColor = true;
            this.btnFragSave.Click += new System.EventHandler(this.btnFragSave_Click);
            // 
            // edtFragEnd
            // 
            resources.ApplyResources(this.edtFragEnd, "edtFragEnd");
            this.edtFragEnd.Name = "edtFragEnd";
            this.edtFragEnd.ValueChanged += new System.EventHandler(this.edtFragEnd_ValueChanged);
            // 
            // btnFragEnd
            // 
            resources.ApplyResources(this.btnFragEnd, "btnFragEnd");
            this.btnFragEnd.Name = "btnFragEnd";
            this.btnFragEnd.UseVisualStyleBackColor = true;
            this.btnFragEnd.Click += new System.EventHandler(this.btnFragEnd_Click);
            // 
            // edtFragStart
            // 
            resources.ApplyResources(this.edtFragStart, "edtFragStart");
            this.edtFragStart.Name = "edtFragStart";
            this.edtFragStart.ValueChanged += new System.EventHandler(this.edtFragStart_ValueChanged);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // btnFragStart
            // 
            resources.ApplyResources(this.btnFragStart, "btnFragStart");
            this.btnFragStart.Name = "btnFragStart";
            this.btnFragStart.UseVisualStyleBackColor = true;
            this.btnFragStart.Click += new System.EventHandler(this.btnFragStart_Click);
            // 
            // lblFirstFrame
            // 
            resources.ApplyResources(this.lblFirstFrame, "lblFirstFrame");
            this.lblFirstFrame.Name = "lblFirstFrame";
            // 
            // lblTotalFrames
            // 
            resources.ApplyResources(this.lblTotalFrames, "lblTotalFrames");
            this.lblTotalFrames.Name = "lblTotalFrames";
            // 
            // lblCurrentFrame
            // 
            resources.ApplyResources(this.lblCurrentFrame, "lblCurrentFrame");
            this.lblCurrentFrame.Name = "lblCurrentFrame";
            // 
            // saveFileDialog
            // 
            resources.ApplyResources(this.saveFileDialog, "saveFileDialog");
            // 
            // listFiles
            // 
            resources.ApplyResources(this.listFiles, "listFiles");
            this.listFiles.FormattingEnabled = true;
            this.listFiles.Name = "listFiles";
            this.listFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listFiles.SelectedIndexChanged += new System.EventHandler(this.listFiles_SelectedIndexChanged);
            this.listFiles.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listFiles_MouseDoubleClick);
            // 
            // lblVersion
            // 
            resources.ApplyResources(this.lblVersion, "lblVersion");
            this.lblVersion.Name = "lblVersion";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // cbLanguage
            // 
            resources.ApplyResources(this.cbLanguage, "cbLanguage");
            this.cbLanguage.FormattingEnabled = true;
            this.cbLanguage.Name = "cbLanguage";
            this.cbLanguage.SelectedIndexChanged += new System.EventHandler(this.cbLanguage_SelectedIndexChanged);
            // 
            // lblLanguageWarning
            // 
            resources.ApplyResources(this.lblLanguageWarning, "lblLanguageWarning");
            this.lblLanguageWarning.ForeColor = System.Drawing.Color.Maroon;
            this.lblLanguageWarning.Name = "lblLanguageWarning";
            // 
            // frmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblLanguageWarning);
            this.Controls.Add(this.cbLanguage);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.listFiles);
            this.Controls.Add(this.lblCurrentFrame);
            this.Controls.Add(this.lblTotalFrames);
            this.Controls.Add(this.lblFirstFrame);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.trkFrames);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.edtFolderName);
            this.Controls.Add(this.lblFolder);
            this.Controls.Add(this.pnlCanvas);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.pnlCanvas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkFrames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtHeight)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlCutFrame.ResumeLayout(false);
            this.pnlCutFrame.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutOffsetX)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtCutWidth)).EndInit();
            this.pnlCutProgress.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragEnd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFragStart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCanvas;
        private System.Windows.Forms.Label lblFolder;
        private System.Windows.Forms.TextBox edtFolderName;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.TrackBar trkFrames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown edtWidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown edtHeight;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trkSpeed;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblFirstFrame;
        private System.Windows.Forms.Label lblTotalFrames;
        private System.Windows.Forms.Label lblCurrentFrame;
        private System.Windows.Forms.CheckBox chkGrid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbMatrixType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbColorOrder;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnFragSave;
        private System.Windows.Forms.NumericUpDown edtFragEnd;
        private System.Windows.Forms.Button btnFragEnd;
        private System.Windows.Forms.NumericUpDown edtFragStart;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFragStart;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ListBox listFiles;
        private System.Windows.Forms.CheckBox chkCutFrame;
        private System.Windows.Forms.Panel pnlCutFrame;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbCutMatrixType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbCutColorOrder;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.NumericUpDown edtCutHeight;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown edtCutWidth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnStartCut;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.NumericUpDown edtCutOffsetY;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown edtCutOffsetX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Panel pnlCutProgress;
        private System.Windows.Forms.ProgressBar progressFrame;
        private System.Windows.Forms.ProgressBar progressFile;
        private System.Windows.Forms.Label lblFileInProcess;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbLanguage;
        private System.Windows.Forms.Label lblLanguageWarning;
    }
}

