﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// Cyotek Color Picker controls library
// Copyright © 2013-2018 Cyotek Ltd.
// http://cyotek.com/blog/tag/colorpicker

// Licensed under the MIT License. See license.txt for the full text.

// If you use this code in your applications, donations or attribution are welcome
// https://www.paypal.me/cyotek

[assembly: AssemblyTitle("Cyotek Color Picker Controls")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cyotek Ltd")]
[assembly: AssemblyProduct("Cyotek Color Picker Controls")]
[assembly: AssemblyCopyright("Copyright © 2013-2018 Cyotek Ltd.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("de546619-59b3-438e-8b5a-3d149e146b22")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.8.0.0")]
[assembly: AssemblyInformationalVersion("1.8.0-alpha2")]
