﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Timer = System.Threading.Timer;
using System.Threading;
using OpenFileOrFolder;
using System.Collections.Generic;
using System.Globalization;

namespace JinxFramer
{
    public partial class frmMain : Form
    {
        private const int margin = 12;

        private string opt_file;           // для хранения текущих настроек
        private string lng_file;           // для хранения настроек выбранного языка
        private readonly Timer timer;      // Таймер анимации

        private Bitmap buffer;

        private float frame_w;             // Ширина кадра
        private float frame_h;             // Высота кадра
        private float pix_size;            // размер "пикселя"

        private int file_index;            // инлекс файла в массиве выбранных файлов
        private string file_name;          // имя файла
        private FileStream file;           // файловый поток с данными

        private int frames_num;            // количество кадров в загруженном файле

        private int frame_s;               // размер буфера кадра
        private byte[] frame_buffer;       // буфер на кадр

        private int cut_frame_s;           // размер буфера кадра
        private byte[] cut_frame_buffer;   // буфер на кадр

        private bool changing;             // флаг изменений

        private byte MATRIX_TYPE;          // тип матрицы: 0 - зигзаг, 1 - параллельная
        private byte CONNECTION_ANGLE;     // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
        private byte STRIP_DIRECTION;      // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
        private byte COLOR_ORDER;          // тип порядка цветов в триаде цвета
        private byte WIDTH;                // Ширина матрицы
        private byte HEIGHT;               // высота матрицы

        private byte CUT_MATRIX_TYPE;      // тип матрицы: 0 - зигзаг, 1 - параллельная
        private byte CUT_CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
        private byte CUT_STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
        private byte CUT_COLOR_ORDER;      // тип порядка цветов в триаде цвета
        private byte CUT_WIDTH;            // Ширина матрицы
        private byte CUT_HEIGHT;           // высота матрицы
        private byte CUT_OFFSET_X;         // Отступ обрезки по X
        private byte CUT_OFFSET_Y;         // Отступ обрезки по Y

        private bool playing;              // Флаг: вкл/выкл анимацию
        private bool save_in_porcess;      // Флаг: вкл/выкл анимацию
        private bool frame_size_ok;        // считанный из файла кадр по размеру соответствкет заданному в настройках
        private byte frame_marker;         // значения маркера разделителя кадров a читаемом файле
        private string lastError;          // Последняя ошибка - текст ошибки

        private string src_folder;         // Папка с исходными файлами
        private string dst_folder;         // Папка для сохранения обработанных файлов

        private string currentLanguage;    // Текущий язык интерфейса

        public frmMain()
        {
            opt_file = Path.ChangeExtension(Application.ExecutablePath, ".opt");
            lng_file = Path.ChangeExtension(Application.ExecutablePath, ".lng");
            timer = new Timer(callback_Animate, null, Timeout.Infinite, Timeout.Infinite);

            if (File.Exists(lng_file))
            {
                try
                {
                    using (BinaryReader reader = new BinaryReader(File.Open(lng_file, FileMode.Open)))
                    {
                        currentLanguage = reader.ReadString();
                    }
                }
                catch { }
            }
            else
            {
                currentLanguage = "ru";
            }

            Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(currentLanguage);
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(currentLanguage);

            InitializeComponent();

            cbMatrixType.Items.Add(Strings.mt01); // Лево-Верх строки вправо
            cbMatrixType.Items.Add(Strings.mt02); // Право-Верх строки влево
            cbMatrixType.Items.Add(Strings.mt03); // Лево-Низ строки вправо
            cbMatrixType.Items.Add(Strings.mt04); // Право-Низ строки влево
            cbMatrixType.Items.Add(Strings.mt05); // Лево-Верх зигзаг вправо
            cbMatrixType.Items.Add(Strings.mt06); // Право-Верх зигзаг влево
            cbMatrixType.Items.Add(Strings.mt07); // Лево-Низ зигзаг вправо
            cbMatrixType.Items.Add(Strings.mt08); // Право-Низ зигзаг влево
            cbMatrixType.Items.Add(Strings.mt09); // Лево-Верх колонки вниз
            cbMatrixType.Items.Add(Strings.mt10); // Право-Верх колонки вниз
            cbMatrixType.Items.Add(Strings.mt11); // Лево-Низ колонки вверх
            cbMatrixType.Items.Add(Strings.mt12); // Право-Низ колонки вверх
            cbMatrixType.Items.Add(Strings.mt13); // Лево-Верх зигзаг вниз
            cbMatrixType.Items.Add(Strings.mt14); // Право-Верх зигзаг вниз
            cbMatrixType.Items.Add(Strings.mt15); // Лево-Низ зигзаг вверх
            cbMatrixType.Items.Add(Strings.mt16); // Право-Низ зигзаг вверх

            cbCutMatrixType.Items.Add(Strings.mt01); // Лево-Верх строки вправо
            cbCutMatrixType.Items.Add(Strings.mt02); // Право-Верх строки влево
            cbCutMatrixType.Items.Add(Strings.mt03); // Лево-Низ строки вправо
            cbCutMatrixType.Items.Add(Strings.mt04); // Право-Низ строки влево
            cbCutMatrixType.Items.Add(Strings.mt05); // Лево-Верх зигзаг вправо
            cbCutMatrixType.Items.Add(Strings.mt06); // Право-Верх зигзаг влево
            cbCutMatrixType.Items.Add(Strings.mt07); // Лево-Низ зигзаг вправо
            cbCutMatrixType.Items.Add(Strings.mt08); // Право-Низ зигзаг влево
            cbCutMatrixType.Items.Add(Strings.mt09); // Лево-Верх колонки вниз
            cbCutMatrixType.Items.Add(Strings.mt10); // Право-Верх колонки вниз
            cbCutMatrixType.Items.Add(Strings.mt11); // Лево-Низ колонки вверх
            cbCutMatrixType.Items.Add(Strings.mt12); // Право-Низ колонки вверх
            cbCutMatrixType.Items.Add(Strings.mt13); // Лево-Верх зигзаг вниз
            cbCutMatrixType.Items.Add(Strings.mt14); // Право-Верх зигзаг вниз
            cbCutMatrixType.Items.Add(Strings.mt15); // Лево-Низ зигзаг вверх
            cbCutMatrixType.Items.Add(Strings.mt16); // Право-Низ зигзаг вверх

            cbMatrixType.SelectedIndex = 0;
            cbColorOrder.SelectedIndex = 0;

            lblLanguageWarning.Visible = false;
        }

        // *****************************************************************************************
        // События
        // *****************************************************************************************

        private void frmMain_Load(object sender, EventArgs e)
        {
            changing = true;
            if (File.Exists(opt_file))
            {
                try
                {
                    using (BinaryReader reader = new BinaryReader(File.Open(opt_file, FileMode.Open)))
                    {
                        edtWidth.Value = reader.ReadByte();
                        edtHeight.Value = reader.ReadByte();
                        cbMatrixType.SelectedIndex = reader.ReadSByte();
                        cbColorOrder.SelectedIndex = reader.ReadSByte();
                        trkSpeed.Value = reader.ReadInt16();
                        chkGrid.Checked = reader.ReadBoolean();

                        edtCutWidth.Value = edtWidth.Value;
                        edtCutHeight.Value = edtHeight.Value;
                        cbCutMatrixType.SelectedIndex = cbMatrixType.SelectedIndex;
                        cbCutColorOrder.SelectedIndex = cbColorOrder.SelectedIndex;
                        edtCutOffsetX.Minimum = 0;
                        edtCutOffsetX.Maximum = 127;
                        edtCutOffsetX.Value = 0;
                        edtCutOffsetY.Minimum = 0;
                        edtCutOffsetY.Maximum = 127;
                        edtCutOffsetY.Value = 0;

                        chkCutFrame.Checked = reader.ReadBoolean();
                        edtCutWidth.Value = reader.ReadByte();
                        edtCutHeight.Value = reader.ReadByte();
                        cbCutMatrixType.SelectedIndex = reader.ReadSByte();
                        cbCutColorOrder.SelectedIndex = reader.ReadSByte();
                        edtCutOffsetX.Value = reader.ReadByte();
                        edtCutOffsetY.Value = reader.ReadByte();

                        src_folder = reader.ReadString();
                        dst_folder = reader.ReadString();
                    }
                }
                catch { }
            }

            changing = true;
            cbLanguage.DataSource = new[]
            {
                CultureInfo.GetCultureInfo("ru"),
                CultureInfo.GetCultureInfo("en")
            };
            cbLanguage.DisplayMember = "NativeName";
            cbLanguage.ValueMember = "Name";

            if (!String.IsNullOrEmpty(currentLanguage))
            {
                cbLanguage.SelectedValue = currentLanguage;
            }
            changing = false;

            lblVersion.Text = Strings.Version + " " + AssemblyVersionInfo.CurrentVersion; // "Версия"

            // Загрузить список файлов из папки
            ScanFiles(src_folder);

            calcFrameArea();

            listFiles.SelectedIndex = listFiles.Items.Count > 0 ? 0 : -1;

            if (listFiles.SelectedIndex >= 0)
            {
                file_name = Path.Combine(src_folder, listFiles.Items[listFiles.SelectedIndex] + ".out");
                openDataFile(file_name);
                LoadFrameFromFile(trkFrames.Value);
                lblWarning.Visible = !frame_size_ok;
            }

            lblCurrentFrame.Text = (trkFrames.Value + 1).ToString();
            edtFolderName.Text = src_folder;

            changing = false;

            CheckCutDimensions();
            enableControls();

            pictureBox.Refresh();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer.Change(Timeout.Infinite, Timeout.Infinite);
            if (file != null) file.Close();

            // создаем объект BinaryWriter
            try
            {
                using (var writer = new BinaryWriter(File.Open(opt_file, FileMode.Create)))
                {
                    // записываем в файл значение каждого поля структуры
                    writer.Write(Convert.ToByte(edtWidth.Value));
                    writer.Write(Convert.ToByte(edtHeight.Value));
                    writer.Write(Convert.ToSByte(cbMatrixType.SelectedIndex));
                    writer.Write(Convert.ToSByte(cbColorOrder.SelectedIndex));
                    writer.Write(Convert.ToInt16(trkSpeed.Value));
                    writer.Write(chkGrid.Checked);

                    writer.Write(chkCutFrame.Checked);
                    writer.Write(Convert.ToByte(edtCutWidth.Value));
                    writer.Write(Convert.ToByte(edtCutHeight.Value));
                    writer.Write(Convert.ToSByte(cbCutMatrixType.SelectedIndex));
                    writer.Write(Convert.ToSByte(cbCutColorOrder.SelectedIndex));
                    writer.Write(Convert.ToByte(edtCutOffsetX.Value));
                    writer.Write(Convert.ToByte(edtCutOffsetY.Value));

                    writer.Write(src_folder ?? "");
                    writer.Write(dst_folder ?? "");
                }
                using (var writer = new BinaryWriter(File.Open(lng_file, FileMode.Create)))
                {
                    writer.Write(currentLanguage);
                }
            }
            catch { }
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            pictureBox.Refresh();
        }

        // Отрисовка кадра на панели
        private void panelCanvas_Paint(object sender, PaintEventArgs e)
        {
            paintFrame();
        }

        private void Dims_ValueChanged(object sender, EventArgs e)
        {
            if (changing) return;
            calcFrameArea();
            CheckCutDimensions();
            LoadFrameFromFile(trkFrames.Value);
            lblWarning.Visible = !frame_size_ok;
            lblCurrentFrame.Text = (trkFrames.Value + 1).ToString();
            pictureBox.Refresh();
        }

        private void chkGrid_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox.Refresh();
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            var folder = SelectDataFolder(Path.GetDirectoryName(file_name));
            if (folder == "") return;

            resetFile();
            resetFile2();

            src_folder = folder;
            edtFolderName.Text = src_folder;
            ScanFiles(folder);

            listFiles.SelectedIndex = listFiles.Items.Count > 0 ? 0 : -1;

            if (listFiles.SelectedIndex >= 0)
            {
                file_name = Path.Combine(src_folder, listFiles.Items[listFiles.SelectedIndex] + ".out");
                openDataFile2(file_name);
                LoadFrameFromFile(trkFrames.Value);
                lblWarning.Visible = !frame_size_ok;
            }

            lblCurrentFrame.Text = (trkFrames.Value + 1).ToString();
            edtFolderName.Text = src_folder;

            changing = false;

            enableControls();
            pictureBox.Refresh();

            SetTitle();
        }

        private void cbMatrixType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;
            // Настройка параметров матрицы для пересчета позиции x,y в номер элемента (триплета)
            decodeMatrixType(cbMatrixType.SelectedIndex);
            pictureBox.Refresh();
        }

        private void cbColorOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;
            pictureBox.Refresh();
        }

        private void cbCutMatrixType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;
            decodeCutMatrixType(cbCutMatrixType.SelectedIndex);
            CheckCutDimensions();
        }

        private void cbCutColorOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;
            CheckCutDimensions();
        }

        private void trkFrames_ValueChanged(object sender, EventArgs e)
        {
            if (changing) return;
            LoadFrameFromFile(trkFrames.Value);
            lblCurrentFrame.Text = (trkFrames.Value + 1).ToString();
            lblWarning.Visible = !frame_size_ok;
            paintFrame();
        }

        private void pnlCanvas_Resize(object sender, EventArgs e)
        {
            calcFrameSize();
            pictureBox.Refresh();
        }

        private void trkSpeed_ValueChanged(object sender, EventArgs e)
        {
            if (playing)
            {
                timer.Change(1, trkSpeed.Maximum - trkSpeed.Value + trkSpeed.Minimum);
            }
        }

        private void callback_Animate(object state)
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker) (() => callback_Animate(state))); }
                catch { }

                return;
            }

            var idx = trkFrames.Value + 1;
            if (idx >= edtFragEnd.Value)
            {
                idx = Convert.ToInt32(edtFragStart.Value) - 1;

                // Загрузить следующий файл из списка выбранных
                if (listFiles.SelectedItems.Count > 1)
                {
                    file_index++;
                    if (file_index >= listFiles.SelectedItems.Count)
                    {
                        file_index = 0;
                    }
                    file_name = Path.Combine(src_folder, (string)listFiles.SelectedItems[file_index] + ".out");
                    openDataFile(file_name);
                    SetTitle();
                }
            }

            trkFrames.Value = idx;

            pictureBox.Refresh();            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            file_index = 0;
            playing = true;
            disableControls();
            pnlCutFrame.Enabled = chkCutFrame.Checked;
            timer.Change(1, trkSpeed.Maximum - trkSpeed.Value + trkSpeed.Minimum);            
            flowLayoutPanel1.Invalidate();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            playing = false;

            enableControls();

            pnlCutFrame.Enabled = chkCutFrame.Checked;
            timer.Change(Timeout.Infinite, Timeout.Infinite);

            if (listFiles.SelectedItems.Count > 1 && listFiles.SelectedIndex >= 0)
            {
                file_name = Path.Combine(src_folder, (string)listFiles.Items[listFiles.SelectedIndex] + ".out");
                resetFile();
                openDataFile(file_name);
            }

            flowLayoutPanel1.Invalidate();
        }

        private void btnFragStart_Click(object sender, EventArgs e)
        {
            edtFragStart.Value = trkFrames.Value + 1;
            if (edtFragEnd.Value < edtFragStart.Value)
            {
                edtFragEnd.Value = edtFragStart.Value;
            }
        }

        private void btnFragEnd_Click(object sender, EventArgs e)
        {
            edtFragEnd.Value = trkFrames.Value + 1;
            if (edtFragStart.Value > edtFragEnd.Value)
            {
                edtFragStart.Value = edtFragEnd.Value;
            }
        }

        private void edtFragStart_ValueChanged(object sender, EventArgs e)
        {
            if (edtFragEnd.Value < edtFragStart.Value)
            {
                edtFragEnd.Value = edtFragStart.Value;
            }
        }

        private void edtFragEnd_ValueChanged(object sender, EventArgs e)
        {
            if (edtFragStart.Value > edtFragEnd.Value)
            {
                edtFragStart.Value = edtFragEnd.Value;
            }
        }

        private void btnFragSave_Click(object sender, EventArgs e)
        {
            saveFileDialog.FileName = file_name;
            var res = saveFileDialog.ShowDialog();
            if (res == DialogResult.OK)
            {
                var new_file_name = saveFileDialog.FileName;
                var same = new_file_name.ToLower() == file_name.ToLower();
                var tmp_file_name = new_file_name + ".new";

                try
                {
                    // Сохранить фрагмент в новый временный файл
                    using (BinaryWriter writer = new BinaryWriter(File.Open(tmp_file_name, FileMode.Create)))
                    {
                        var start_frame = Convert.ToInt32(edtFragStart.Value) - 1;
                        var end_frame = Convert.ToInt32(edtFragEnd.Value) - 1;
                        var num_frames = end_frame - start_frame + 1;

                        long position = start_frame * (frame_s + 1);
                        long length = num_frames * (frame_s + 1);
                        file.Position = position;

                        for (long i = 0; i < length; i++)
                        {
                            var b = Convert.ToByte(file.ReadByte());
                            writer.Write(b);
                        }
                    }

                    // Если файл тот же самый - удалить старый файл
                    if (same)
                    {
                        file.Close();
                        file = null;
                        File.Delete(file_name);
                    }

                    // Переименовать временный файл в постоянное имя
                    if (File.Exists(new_file_name))
                    {
                        File.Delete(new_file_name);
                    }

                    File.Move(tmp_file_name, new_file_name);
                    file_name = new_file_name;

                    resetFile();
                    openDataFile(file_name);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Strings.SaveFileError + " '" + new_file_name + "'\n\n" + ex.Message, Strings.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void listFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;

            resetFile();
            file_name = Path.Combine(src_folder, (string)listFiles.Items[listFiles.SelectedIndex] + ".out");
            openDataFile(file_name);

            Text = String.Format("Jinx Frame Viewer [{0}]", listFiles.Items[listFiles.SelectedIndex]);
        }

        private void listFiles_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            btnStart_Click(null, null);
        }

        private void chkCutFrame_CheckedChanged(object sender, EventArgs e)
        {
            pnlCutFrame.Enabled = chkCutFrame.Checked;
            btnStartCut.Enabled = chkCutFrame.Checked;
        }

        private void edtCutWidth_ValueChanged(object sender, EventArgs e)
        {
            CheckCutDimensions();
        }

        private void edtCutHeight_ValueChanged(object sender, EventArgs e)
        {
            CheckCutDimensions();
        }

        private void edtCutOffsetX_ValueChanged(object sender, EventArgs e)
        {
            CheckCutDimensions();
        }

        private void edtCutOffsetY_ValueChanged(object sender, EventArgs e)
        {
            CheckCutDimensions();
        }

        private void pnlCanvas_Resize_1(object sender, EventArgs e)
        {
            pictureBox.Width = pnlCanvas.Width;
            pictureBox.Height = pnlCanvas.Height;
            pictureBox.MinimumSize = new Size(pnlCanvas.Width, pnlCanvas.Height);
        }

        private void btnStartCut_Click(object sender, EventArgs e)
        {
            if (save_in_porcess)
            {
                btnStartCut.Text = Strings.Stopping; // "Остановка. Ждите...";
                btnStartCut.Enabled = false;
                save_in_porcess = false;
                return;
            }

            // Запрос папки сохранения
            dst_folder = SelectDataFolder(string.IsNullOrEmpty(dst_folder) ? src_folder : dst_folder, Strings.ChooseSaveFolder);
            if (dst_folder == "") return;

            decodeMatrixType(cbMatrixType.SelectedIndex);
            decodeCutMatrixType(cbCutMatrixType.SelectedIndex);

            // Выделение памяти под буфер кадра обрезки
            cut_frame_s = Convert.ToInt32(CUT_WIDTH * CUT_HEIGHT * 3);
            cut_frame_buffer = new byte[cut_frame_s];

            save_in_porcess = true;

            btnStartCut.Text = Strings.StopAction; // "Остановить";

            // Список файлов для обработки
            var sl = new List<string>();
            foreach (var item in listFiles.SelectedItems)
            {
                sl.Add((string)item);
            }

            disableControls();

            btnStartCut.Enabled = true;
            btnStop.Enabled = false;
            trkFrames.Enabled = false;
            trkSpeed.Enabled = false;

            // Отдельный поток в котором будет выполняться обработка файлов для перекодирования
            var thread = new Thread(o => processCutFiles(src_folder, dst_folder, sl));
            thread.SetApartmentState(ApartmentState.MTA);
            thread.IsBackground = true;

            thread.Start();
        }
        
        // *****************************************************************************************
        // Методы
        // *****************************************************************************************

        private void resetFile()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => resetFile())); } catch { }
                return;
            }

            playing = false;
            lblWarning.Visible = false;
            btnStart.Enabled = false;
            btnStop.Enabled = false;
            lblFirstFrame.Visible = false;
            lblCurrentFrame.Visible = false;
            lblTotalFrames.Visible = false;
            trkFrames.Enabled = false;
            frames_num = 0;

            edtFragStart.Minimum = 0;
            edtFragStart.Value = 0;
            edtFragStart.Maximum = 1;
            edtFragEnd.Minimum = 0;
            edtFragEnd.Value = 0;
            edtFragEnd.Maximum = 1;

            edtFragStart.Enabled = false;
            edtFragEnd.Enabled = false;
            btnFragStart.Enabled = false;
            btnFragEnd.Enabled = false;
            btnFragSave.Enabled = false;

            changing = true;
            trkFrames.Value = 0;
            changing = false;

            timer.Change(Timeout.Infinite, Timeout.Infinite);
            if (file != null)
            {
                file.Close();
                file = null;
            }
        }

        private void resetFile2()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => resetFile2())); } catch { }
                return;
            }

            edtFolderName.Text = "";
            changing = true;
            listFiles.Items.Clear();
            changing = false;
        }

        private void calcFrameArea()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => calcFrameArea())); } catch { }
                return;
            }

            WIDTH = Convert.ToByte(edtWidth.Value);
            HEIGHT = Convert.ToByte(edtHeight.Value);
            COLOR_ORDER = (byte)cbColorOrder.SelectedIndex;

            decodeMatrixType(cbMatrixType.SelectedIndex);
            calcFrameSize();

            frame_s = Convert.ToInt32(WIDTH * HEIGHT * 3);
            frame_buffer = new byte[frame_s];
            Array.Clear(frame_buffer, 0, frame_s);
        }

        private void calcFrameSize()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => calcFrameSize())); } catch { }
                return;
            }

            var w = (pnlCanvas.Width - 2 * margin) / (double) WIDTH;
            var h = (pnlCanvas.Height - 2 * margin) / (double) HEIGHT;

            pix_size = Convert.ToSingle(Math.Min(w, h));
            frame_w = pix_size * Convert.ToSingle(WIDTH);
            frame_h = pix_size * Convert.ToSingle(HEIGHT);

            buffer = new Bitmap(pnlCanvas.Width, pnlCanvas.Height);
        }

        private bool LoadFrameFromFile(int num)
        {
            var ok = true;
            try
            {
                long position = num * (frame_s + 1);
                file.Position = position;

                // читать первый байт кадра - это маркер начала фрейма / канала
                // В начале файла - всегда верный маркер. Если читать в середине и 
                // размеры матрицы заданы неправильно - будет считан неправильный байт маркера -
                // поэтому запоминаем только в самом начале файла один раз
                var b = (byte)file.ReadByte();
                if (position == 0) frame_marker = b;

                // Размер кадра - W*H*3 - 3 байта на цвет точки
                Array.Clear(frame_buffer, 0, frame_s);
                var cnt = file.Read(frame_buffer, 0, frame_s);

                // Следующий байт в кадре должен иметь метку начала кадра
                int mark2 = frame_marker;
                if (file.Position < file.Length - 1)
                {
                    mark2 = file.ReadByte();
                }

                frame_size_ok = frame_marker == mark2;

                if (cnt != frame_s)
                {
                    throw new Exception(Strings.NotEnoughData + num + " (" + edtWidth.Value + "x" + edtHeight.Value + ")");
                }

            }
            catch (Exception ex)
            {
                lastError = Strings.FrameLoadError + " '" + num + "'\n\n" + ex.Message; // "Ошибка загрузки кадра"
                ok = false;
            }
            return ok;
        }

        private void decodeMatrixType(int type)
        {
            /*
                MATRIX_TYPE;      // тип матрицы: 0 - зигзаг, 1 - параллельная
                CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            switch (type)
            {
                case 0: // Лево-Верх строки вправо
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 1;
                    STRIP_DIRECTION = 0;
                    break;
                case 1: // Право-Верх строки влево
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 2;
                    STRIP_DIRECTION = 2;
                    break;
                case 2: // Лево-Низ строки вправо
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 0;
                    STRIP_DIRECTION = 0;
                    break;
                case 3: // Право-Низ строки влево
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 3;
                    STRIP_DIRECTION = 2;
                    break;
                case 4: // Лево-Верх зигзаг вправо
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 1;
                    STRIP_DIRECTION = 0;
                    break;
                case 5: // Право-Верх зигзаг влево
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 2;
                    STRIP_DIRECTION = 2;
                    break;
                case 6: // Лево-Низ зигзаг вправо
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 0;
                    STRIP_DIRECTION = 0;
                    break;
                case 7: // Право-Низ зигзаг влево
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 3;
                    STRIP_DIRECTION = 2;
                    break;
                case 8: // Лево-Верх колонки вниз
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 1;
                    STRIP_DIRECTION = 3;
                    break;
                case 9: // Право-Верх колонки вниз
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 2;
                    STRIP_DIRECTION = 3;
                    break;
                case 10: // Лево-Низ колонки вверх
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 0;
                    STRIP_DIRECTION = 1;
                    break;
                case 11: // Право-Низ колонки вверх
                    MATRIX_TYPE = 1;
                    CONNECTION_ANGLE = 3;
                    STRIP_DIRECTION = 1;
                    break;
                case 12: // Лево-Верх зигзаг вниз
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 1;
                    STRIP_DIRECTION = 3;
                    break;
                case 13: // Право-Верх зигзаг вниз
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 2;
                    STRIP_DIRECTION = 3;
                    break;
                case 14: // Лево-Низ зигзаг вверх
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 0;
                    STRIP_DIRECTION = 1;
                    break;
                case 15: // Право-Низ зигзаг вверх
                    MATRIX_TYPE = 0;
                    CONNECTION_ANGLE = 3;
                    STRIP_DIRECTION = 1;
                    break;
            }
        }

        // получить номер пикселя в ленте по координатам
        private int getPixelNumber(byte x, byte y)
        {
            var xx = THIS_X(x, y);
            var yy = THIS_Y(x, y);
            var ww = THIS_W(x, y);

            return (yy % 2 == 0 || MATRIX_TYPE == 1)
                ? yy * ww + xx // если чётная строка
                : yy * ww + ww - xx - 1; // если нечётная строка
        }

        private byte THIS_X(byte x, byte y)
        {
            /*
                CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 0) return x;
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 1) return y;
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 0) return x;
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 3) return Convert.ToByte(HEIGHT - y - 1);
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 2) return Convert.ToByte(WIDTH - x - 1);
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 3) return Convert.ToByte(HEIGHT - y - 1);
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 2) return Convert.ToByte(WIDTH - x - 1);
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 1) return y;
            return x;
        }

        private byte THIS_Y(byte x, byte y)
        {
            /*
                CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 0) return y;
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 1) return x;
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 0) return Convert.ToByte(HEIGHT - y - 1);
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 3) return x;
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 2) return Convert.ToByte(HEIGHT - y - 1);
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 3) return Convert.ToByte(WIDTH - x - 1);
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 2) return y;
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 1) return Convert.ToByte(WIDTH - x - 1);
            return y;
        }

        private byte THIS_W(byte x, byte y)
        {
            /*
                CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 0) return WIDTH;
            if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 1) return HEIGHT;
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 0) return WIDTH;
            if (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 3) return HEIGHT;
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 2) return WIDTH;
            if (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 3) return HEIGHT;
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 2) return WIDTH;
            if (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 1) return HEIGHT;
            return WIDTH;
        }


        private void decodeCutMatrixType(int type)
        {
            /*
                CUT_MATRIX_TYPE;      // тип матрицы: 0 - зигзаг, 1 - параллельная
                CUT_CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                CUT_STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            switch (type)
            {
                case 0: // Лево-Верх строки вправо
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 1;
                    CUT_STRIP_DIRECTION = 0;
                    break;
                case 1: // Право-Верх строки влево
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 2;
                    CUT_STRIP_DIRECTION = 2;
                    break;
                case 2: // Лево-Низ строки вправо
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 0;
                    CUT_STRIP_DIRECTION = 0;
                    break;
                case 3: // Право-Низ строки влево
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 3;
                    CUT_STRIP_DIRECTION = 2;
                    break;
                case 4: // Лево-Верх зигзаг вправо
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 1;
                    CUT_STRIP_DIRECTION = 0;
                    break;
                case 5: // Право-Верх зигзаг влево
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 2;
                    CUT_STRIP_DIRECTION = 2;
                    break;
                case 6: // Лево-Низ зигзаг вправо
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 0;
                    CUT_STRIP_DIRECTION = 0;
                    break;
                case 7: // Право-Низ зигзаг влево
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 3;
                    CUT_STRIP_DIRECTION = 2;
                    break;
                case 8: // Лево-Верх колонки вниз
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 1;
                    CUT_STRIP_DIRECTION = 3;
                    break;
                case 9: // Право-Верх колонки вниз
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 2;
                    CUT_STRIP_DIRECTION = 3;
                    break;
                case 10: // Лево-Низ колонки вверх
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 0;
                    CUT_STRIP_DIRECTION = 1;
                    break;
                case 11: // Право-Низ колонки вверх
                    CUT_MATRIX_TYPE = 1;
                    CUT_CONNECTION_ANGLE = 3;
                    CUT_STRIP_DIRECTION = 1;
                    break;
                case 12: // Лево-Верх зигзаг вниз
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 1;
                    CUT_STRIP_DIRECTION = 3;
                    break;
                case 13: // Право-Верх зигзаг вниз
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 2;
                    CUT_STRIP_DIRECTION = 3;
                    break;
                case 14: // Лево-Низ зигзаг вверх
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 0;
                    CUT_STRIP_DIRECTION = 1;
                    break;
                case 15: // Право-Низ зигзаг вверх
                    CUT_MATRIX_TYPE = 0;
                    CUT_CONNECTION_ANGLE = 3;
                    CUT_STRIP_DIRECTION = 1;
                    break;
            }
        }

        // получить номер пикселя в ленте по координатам
        private int getCutPixelNumber(byte x, byte y)
        {
            var xx = CUT_THIS_X(x, y);
            var yy = CUT_THIS_Y(x, y);
            var ww = CUT_THIS_W(x, y);

            return (yy % 2 == 0 || CUT_MATRIX_TYPE == 1)
                ? yy * ww + xx           // если чётная строка
                : yy * ww + ww - xx - 1; // если нечётная строка
        }

        private byte CUT_THIS_X(byte x, byte y)
        {
            /*
                CUT_CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                CUT_STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 0) return x;
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 1) return y;
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 0) return x;
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 3) return Convert.ToByte(CUT_HEIGHT - y - 1);
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 2) return Convert.ToByte(CUT_WIDTH - x - 1);
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 3) return Convert.ToByte(CUT_HEIGHT - y - 1);
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 2) return Convert.ToByte(CUT_WIDTH - x - 1);
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 1) return y;
            return x;
        }

        private byte CUT_THIS_Y(byte x, byte y)
        {
            /*
                CUT_CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                CUT_STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 0) return y;
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 1) return x;
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 0) return Convert.ToByte(CUT_HEIGHT - y - 1);
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 3) return x;
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 2) return Convert.ToByte(CUT_HEIGHT - y - 1);
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 3) return Convert.ToByte(CUT_WIDTH - x - 1);
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 2) return y;
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 1) return Convert.ToByte(CUT_WIDTH - x - 1);
            return y;
        }

        private byte CUT_THIS_W(byte x, byte y)
        {
            /*
                CUT_CONNECTION_ANGLE; // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний
                CUT_STRIP_DIRECTION;  // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз
             */
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 0) return CUT_WIDTH;
            if (CUT_CONNECTION_ANGLE == 0 && CUT_STRIP_DIRECTION == 1) return CUT_HEIGHT;
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 0) return CUT_WIDTH;
            if (CUT_CONNECTION_ANGLE == 1 && CUT_STRIP_DIRECTION == 3) return CUT_HEIGHT;
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 2) return CUT_WIDTH;
            if (CUT_CONNECTION_ANGLE == 2 && CUT_STRIP_DIRECTION == 3) return CUT_HEIGHT;
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 2) return CUT_WIDTH;
            if (CUT_CONNECTION_ANGLE == 3 && CUT_STRIP_DIRECTION == 1) return CUT_HEIGHT;
            return CUT_WIDTH;
        }

        private Color getColor(byte b1, byte b2, byte b3, byte order)
        {
            switch (order)
            {
                case 0:  return Color.FromArgb(b1, b2, b3); // RGB
                case 1:  return Color.FromArgb(b1, b3, b2); // RBG
                case 2:  return Color.FromArgb(b3, b2, b1); // BGR
                case 3:  return Color.FromArgb(b3, b2, b1); // BRG
                case 4:  return Color.FromArgb(b2, b3, b1); // GBR
                case 5:  return Color.FromArgb(b2, b1, b3); // GRB
                default: return Color.FromArgb(b1, b2, b3);
            }
        }

        private byte[] getBytes(Color color, byte order)
        {
            var b = new byte[3];
            switch (order)
            {
                case 0:  b[0] = color.R; b[1] = color.G; b[2] = color.B; break; // RGB
                case 1:  b[0] = color.R; b[1] = color.B; b[2] = color.G; break; // RBG
                case 2:  b[0] = color.B; b[1] = color.G; b[2] = color.R; break; // BGR
                case 3:  b[0] = color.B; b[1] = color.R; b[2] = color.G; break; // BRG
                case 4:  b[0] = color.G; b[1] = color.B; b[2] = color.R; break; // GBR
                case 5:  b[0] = color.G; b[1] = color.R; b[2] = color.B; break; // GRB
                default: b[0] = color.R; b[1] = color.G; b[2] = color.B; break; 
            }
            return b;
        }

        // Отрисовка кадра на панели
        private void paintFrame()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => paintFrame())); } catch { }
                return;
            }

            // Левый верхний угол кадра в координатах окна, у которого угол x=0, y=0 - левый верхний
            // Левый верхний угол матрицы, у которого угол x=0, y=0 - левый нижний
            var fx = margin + Convert.ToInt32((pnlCanvas.Width - (2 * margin) - frame_w) / 2.0F);
            var fy = margin + Convert.ToInt32((pnlCanvas.Height - (2 * margin) - frame_h) / 2.0F);

            using (var g = Graphics.FromImage(buffer))
            {
                for (byte x = 0; x < WIDTH; x++)
                {
                    for (byte y = 0; y < HEIGHT; y++)
                    {
                        var idx = getPixelNumber(x, y) * 3; // 3 байта на цвет
                        var b1 = frame_buffer[idx];
                        var b2 = frame_buffer[idx + 1];
                        var b3 = frame_buffer[idx + 2];
                        var ix = COLOR_ORDER;

                        var color = getColor(b1, b2, b3, ix);
                        using (var brush = new SolidBrush(color))
                        {
                            var px = fx + x * pix_size;
                            var py = fy + frame_h - (y + 1) * pix_size;
                            g.FillRectangle(brush, px, py, pix_size, pix_size);
                        }
                    }
                }

                // Рисовать границы кадра
                if (!(playing || save_in_porcess))
                {
                    var pen = new Pen(Color.Gray);
                    g.DrawRectangle(pen, fx, fy, frame_w, frame_h);
                }

                // Рисовать сетку
                if (chkGrid.Checked)
                {
                    var pen = new Pen(Color.Gray);
                    for (int i = 1; i < edtWidth.Value; i++)
                    {
                        var ix = fx + i * pix_size;
                        g.DrawLine(pen, ix, fy, ix, fy + frame_h);
                    }

                    for (int i = 1; i < edtHeight.Value; i++)
                    {
                        var iy = fy + i * pix_size;
                        g.DrawLine(pen, fx, iy, fx + frame_w, iy);
                    }
                }

                // Если включена обрезка - рисовать рамку обрезаемой площади
                if (chkCutFrame.Checked)
                {
                    // Координаты поля рисования - 0,0 - верхний левый угол холста
                    // Координаты 0,0 матрицы - левый нижний угол окна (поля матрицы)
                    var dy = (int)(edtCutOffsetY.Maximum - edtCutOffsetY.Value);
                    var pen = new Pen(Color.Lime);
                    var ix  = fx + (int)edtCutOffsetX.Value * pix_size;
                    var iy  = fy + dy * pix_size;
                    var ix2 = fx + (int)(edtCutOffsetX.Value + edtCutWidth.Value) * pix_size;
                    var iy2 = fy + (int)(dy + edtCutHeight.Value) * pix_size;
                    g.DrawLine(pen, ix,  iy,  ix2, iy);
                    g.DrawLine(pen, ix,  iy,  ix,  iy2);
                    g.DrawLine(pen, ix2, iy,  ix2, iy2);
                    g.DrawLine(pen, ix,  iy2, ix2, iy2);
                }
            }

            pictureBox.Image = buffer;
        }

        bool openDataFile2(string fname)
        {
            var frame_ok = true;
            try
            {
                if (file != null) file.Close();
                file = File.Open(fname, FileMode.Open);

                if (file.Length == 0)
                {
                    throw new Exception(Strings.NoDataInFile);
                }

                frames_num = Convert.ToInt32(file.Length / (frame_s + 1));

                // читать первый байт файла - это маркер начала фрейма / канала
                int mark = file.ReadByte();

                // Размер кадра - W*H*3 - 3 байта на цвет точки
                Array.Clear(frame_buffer, 0, frame_s);
                var cnt = file.Read(frame_buffer, 0, frame_s);
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                frame_ok = false;
            }
            return frame_ok;
        }

        void openDataFile(string fname)
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => openDataFile(fname))); } catch { }
                return;
            }

            var frame_ok = openDataFile2(fname);

            if (frame_ok)
            {
                changing = true;
                lblCurrentFrame.Text = "1";
                lblTotalFrames.Text = frames_num.ToString();

                trkFrames.Minimum = 0;
                trkFrames.Maximum = frames_num - 1;
                trkFrames.Value = 0;

                edtFragStart.Minimum = trkFrames.Minimum + 1;
                edtFragStart.Maximum = trkFrames.Maximum + 1;
                edtFragStart.Value = trkFrames.Minimum + 1;

                edtFragEnd.Minimum = trkFrames.Minimum + 1;
                edtFragEnd.Maximum = trkFrames.Maximum + 1;
                edtFragEnd.Value = trkFrames.Maximum + 1;
                changing = false;

                if (!(playing || save_in_porcess))
                {
                    btnStart.Enabled = true;
                    lblFirstFrame.Visible = true;
                    lblCurrentFrame.Visible = true;
                    lblTotalFrames.Visible = true;
                    trkFrames.Enabled = true;
                    edtFragStart.Enabled = true;
                    edtFragEnd.Enabled = true;
                    btnFragStart.Enabled = true;
                    btnFragEnd.Enabled = true;
                    btnFragSave.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show(Strings.FileOpenError + " '" + fname + "'\n\n" + lastError, Strings.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            pictureBox.Refresh();

        }

        /// <summary>
        /// Выбор папки
        /// </summary>
        /// <param name="DataPath">Папка по умолчанию</param>
        /// <param name="Title">Заголовок окна диалога выбора папки</param>
        /// <returns>Папка хранилища</returns>
        public string SelectDataFolder(string DataPath, string Title = "")
        {
            var folders = SelectDataFolders(DataPath, false, Title);

            var dataFolder = folders.Length > 0 ? folders[0] : "";

            if (string.IsNullOrWhiteSpace(dataFolder)) return "";

            return dataFolder;
        }

        /// <summary>
        /// Множественный выбор папкок
        /// </summary>
        /// <param name="DataPath">Папка по умолчанию</param>
        /// <param name="multiSelect">Флаг: допускается выбор нескольких папок</param>
        /// <param name="Title">Заголовок диалога выбора папки</param>
        /// <returns>Список папок</returns>
        public string[] SelectDataFolders(string DataPath, bool multiSelect = false, string Title = "")
        {
            var dialog = new FolderSelectDialog
            {
                MultiSelect = multiSelect,
                InitialDirectory = DataPath,
                Title = string.IsNullOrWhiteSpace(Title) ? Strings.ChooseFolder : Title,
            };

            if (dialog.ShowDialog() != DialogResult.OK) return new string[0];

            return dialog.DirectoryPaths ?? new string[0];
        }

        void ScanFiles(string folder)
        {
            if (!Directory.Exists(folder))
            {
                folder = Path.GetDirectoryName(Application.ExecutablePath);
            }

            var files = Directory.GetFiles(folder, "*.out", SearchOption.TopDirectoryOnly);
            if (files.Length > 0)
            {
                foreach (var file in files)
                {
                    listFiles.Items.Add(Path.GetFileNameWithoutExtension(file));
                }
            }
        }

        void SetTitle()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => SetTitle())); } catch { }
                return;
            }
            
            Text = playing || save_in_porcess
                ? file_index >= 0 ? String.Format("Jinx Frame Viewer [{0}]", listFiles.SelectedItems[file_index]) : "Jinx Frame Viewer"
                : listFiles.SelectedIndex >= 0 ? String.Format("Jinx Frame Viewer [{0}]", listFiles.Items[listFiles.SelectedIndex]) : "Jinx Frame Viewer";
        }

        void CheckCutDimensions()
        {
            if (changing) return;

            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => CheckCutDimensions())); } catch { }
                return;
            }

            pnlCutFrame.Enabled = chkCutFrame.Checked;

            if (edtCutWidth.Value > edtWidth.Value) edtCutWidth.Value = edtWidth.Value;
            edtCutWidth.Minimum = edtWidth.Minimum;
            edtCutWidth.Maximum = edtWidth.Maximum;

            if (edtCutHeight.Value > edtHeight.Value) edtCutHeight.Value = edtHeight.Value;
            edtCutHeight.Minimum = edtHeight.Minimum;
            edtCutHeight.Maximum = edtHeight.Maximum;

            var val_x = edtCutOffsetX.Value;
            while (edtCutWidth.Value + val_x > edtWidth.Value && val_x > 0) val_x--;
            edtCutOffsetX.Value = val_x;

            var val_y = edtCutOffsetY.Value;
            while (edtCutHeight.Value + val_y > edtHeight.Value && val_y > 0) val_y--;
            edtCutOffsetY.Value = val_y;

            edtCutOffsetX.Maximum = edtWidth.Value - edtCutWidth.Value;
            edtCutOffsetY.Maximum = edtHeight.Value - edtCutHeight.Value;

            CUT_WIDTH = Convert.ToByte(edtCutWidth.Value);
            CUT_HEIGHT = Convert.ToByte(edtCutHeight.Value);
            CUT_OFFSET_X = Convert.ToByte(edtCutOffsetX.Value);
            CUT_OFFSET_Y = Convert.ToByte(edtCutOffsetY.Value);
            CUT_COLOR_ORDER = (byte)cbCutColorOrder.SelectedIndex;

            pictureBox.Refresh();
        }

        private void disableControls()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => disableControls())); } catch { }
                return;
            }

            btnStart.Enabled = false;
            btnStop.Enabled = true;
            btnOpenFile.Enabled = false;
            btnFragSave.Enabled = false;
            edtWidth.Enabled = false;
            edtHeight.Enabled = false;
            cbMatrixType.Enabled = false;
            cbColorOrder.Enabled = false;
            listFiles.Enabled = false;
            btnFragStart.Enabled = false;
            btnFragEnd.Enabled = false;
            edtFragStart.Enabled = false;
            edtFragEnd.Enabled = false;
            chkCutFrame.Enabled = false;
            pnlCutFrame.Enabled = false;
            btnStartCut.Enabled = false;
        }

        private void enableControls()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => enableControls())); } catch { }
                return;
            }

            var enable = listFiles.Items.Count > 0;

            btnStart.Enabled = enable && !playing;
            btnStop.Enabled = playing;
            btnOpenFile.Enabled = true;
            btnFragSave.Enabled = enable;
            edtWidth.Enabled = true;
            edtHeight.Enabled = true;
            cbMatrixType.Enabled = true;
            cbColorOrder.Enabled = true;
            listFiles.Enabled = true;
            btnFragStart.Enabled = true;
            btnFragEnd.Enabled = true;
            edtFragStart.Enabled = true;
            edtFragEnd.Enabled = true;
            chkCutFrame.Enabled = enable;
            pnlCutFrame.Enabled = enable && chkCutFrame.Checked;
            btnStartCut.Enabled = enable && chkCutFrame.Checked;
            trkFrames.Enabled = true;
            trkSpeed.Enabled = true;

            btnStartCut.Text = Strings.CutAction; // "Обрезать"
        }

        private void processCutFiles(string src_folder, string dst_folder, List<string> files)
        {
            initFileProgress(files.Count);
            file_index = 0;

            foreach (var fName in files)
            {
                if (!save_in_porcess) break;

                updateFileProgress(fName);

                try
                {
                    var file_in = Path.Combine(src_folder, (string)fName + ".out");
                    var file_out = Path.Combine(dst_folder, (string)fName + ".out");

                    openDataFile2(file_in);

                    initFrameProgress(frames_num);

                    SetTitle();

                    // Сохранить фрагмент в новый временный файл
                    using (var writer = new BinaryWriter(File.Open(file_out, FileMode.Create)))
                    {
                        for (var i = 0; i < frames_num; i++)
                        {
                            updateFrameProgress();

                            var ok = LoadFrameFromFile(i);
                            if (!ok) throw new Exception(lastError);
                            RefreshPictureBox();

                            for (byte x = 0; x < CUT_WIDTH; x++)
                            {
                                for (byte y = 0; y < CUT_HEIGHT; y++)
                                {
                                    var idx = getPixelNumber((byte)(CUT_OFFSET_X + x), (byte)(CUT_OFFSET_Y + y)) * 3; // 3 байта на цвет
                                    var b1 = frame_buffer[idx];
                                    var b2 = frame_buffer[idx + 1];
                                    var b3 = frame_buffer[idx + 2];

                                    var color = getColor(b1, b2, b3, COLOR_ORDER);
                                    var arr = getBytes(color, CUT_COLOR_ORDER);

                                    idx = getCutPixelNumber(x, y) * 3; // 3 байта на цвет

                                    cut_frame_buffer[idx] = arr[0];
                                    cut_frame_buffer[idx + 1] = arr[1];
                                    cut_frame_buffer[idx + 2] = arr[2];
                                }
                            }

                            // Разделитель кадров в файле
                            writer.Write(frame_marker);

                            // Сохранить буфер кадра
                            for (var ii = 0; ii < cut_frame_s; ii++)
                            {
                                writer.Write(cut_frame_buffer[ii]);
                            }
                        }

                        writer.Close();
                    }
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                }
                finally
                {
                    if (file != null)
                    {
                        file.Close();
                        file = null;
                    }
                }

                file_index++;
            }

            file_name = Path.Combine(src_folder, files[0] + ".out");
            openDataFile2(file_name);

            save_in_porcess = false;
            stopProgress();
        }

        void RefreshPictureBox()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => RefreshPictureBox())); } catch { }
                return;
            }

            pictureBox.Refresh();
        }

        void initFileProgress(int file_total)
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => initFileProgress(file_total))); } catch { }
                return;
            }

            pnlCutProgress.Visible = true;
            progressFile.Minimum = 0;
            progressFile.Value = 1;
            progressFile.Maximum = file_total;
        }

        void initFrameProgress(int frames_num)
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => initFrameProgress(frames_num))); } catch { }
                return;
            }

            changing = true;
            lblCurrentFrame.Text = "1";
            lblTotalFrames.Text = frames_num.ToString();
            trkFrames.Minimum = 0;
            trkFrames.Value = 0;
            trkFrames.Maximum = frames_num;
            progressFrame.Minimum = 0;
            progressFrame.Value = 1;
            progressFrame.Maximum = frames_num;
            changing = false;
        }

        void updateFileProgress(string fileName)
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => updateFileProgress(fileName))); } catch { }
                return;
            }

            lblFileInProcess.Text = fileName;
            progressFile.PerformStep();
        }

        void updateFrameProgress()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => updateFrameProgress())); } catch { } 
                return;
            }

            changing = true;
            progressFrame.PerformStep();
            trkFrames.Value = trkFrames.Value + 1;
            lblCurrentFrame.Text = trkFrames.Value.ToString();
            changing = false;
        }

        void stopProgress()
        {
            if (InvokeRequired)
            {
                try { Invoke((MethodInvoker)(() => stopProgress())); } catch { }
                return;
            }

            pnlCutProgress.Visible = false;

            changing = true;
            lblCurrentFrame.Text = "1";
            lblTotalFrames.Text = frames_num.ToString();
            trkFrames.Minimum = 0;
            trkFrames.Value = 0;
            trkFrames.Maximum = frames_num;
            progressFrame.Minimum = 0;
            progressFrame.Value = 1;
            progressFrame.Maximum = frames_num;
            changing = false;

            enableControls();
        }

        private void cbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (changing) return;
            currentLanguage = ((CultureInfo)cbLanguage.SelectedItem).Name;
            lblLanguageWarning.Visible = true;
        }
    }

}
