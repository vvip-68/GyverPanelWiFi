using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Defines string constants for application version information.
/// </summary>
internal static class AssemblyVersionInfo
{
    /// <summary>
    /// The current copy right notice.
    /// </summary>
    public const string Copyright = "Copyright © vvip-68, 2021";

    /// <summary>
    /// The current build version.
    /// </summary>
    public const string CurrentVersion = "1.1.2021.0316";

    /// <summary>
    /// The current build file version.
    /// </summary>
    public const string CurrentFileVersion = "1.1.2021.0316";
}
