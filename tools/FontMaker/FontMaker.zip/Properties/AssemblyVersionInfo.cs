using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Defines string constants for application version information.
/// </summary>
internal static class AssemblyVersionInfo
{
    /// <summary>
    /// The current copy right notice.
    /// </summary>
    public const string Company = "vvip-68";

    /// <summary>
    /// The current copy right notice.
    /// </summary>
    public const string Copyright = "Copyright © vvip-68, 2021-2022";

    /// <summary>
    /// The current build version.
    /// </summary>
    public const string CurrentVersion = "1.12.2022.1118";

    /// <summary>
    /// The current build file version.
    /// </summary>
    public const string CurrentFileVersion = "1.12.2022.1118";
}
