﻿namespace FontMaker
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.edtFontWidth = new System.Windows.Forms.NumericUpDown();
            this.edtFontHeight = new System.Windows.Forms.NumericUpDown();
            this.pnlCharImage = new System.Windows.Forms.Panel();
            this.pnlHexLines = new System.Windows.Forms.Panel();
            this.edtHexArray = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontHeight)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Размер символа (Ш x В)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(205, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "x";
            // 
            // edtFontWidth
            // 
            this.edtFontWidth.Location = new System.Drawing.Point(148, 7);
            this.edtFontWidth.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtFontWidth.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.edtFontWidth.Name = "edtFontWidth";
            this.edtFontWidth.Size = new System.Drawing.Size(51, 20);
            this.edtFontWidth.TabIndex = 2;
            this.edtFontWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFontWidth.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.edtFontWidth.ValueChanged += new System.EventHandler(this.charSizeChanged);
            // 
            // edtFontHeight
            // 
            this.edtFontHeight.Location = new System.Drawing.Point(223, 7);
            this.edtFontHeight.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.edtFontHeight.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.edtFontHeight.Name = "edtFontHeight";
            this.edtFontHeight.Size = new System.Drawing.Size(51, 20);
            this.edtFontHeight.TabIndex = 3;
            this.edtFontHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.edtFontHeight.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.edtFontHeight.ValueChanged += new System.EventHandler(this.charSizeChanged);
            // 
            // pnlCharImage
            // 
            this.pnlCharImage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCharImage.Location = new System.Drawing.Point(15, 36);
            this.pnlCharImage.Name = "pnlCharImage";
            this.pnlCharImage.Size = new System.Drawing.Size(406, 441);
            this.pnlCharImage.TabIndex = 4;
            this.pnlCharImage.Resize += new System.EventHandler(this.pnlCharImage_Resize);
            // 
            // pnlHexLines
            // 
            this.pnlHexLines.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlHexLines.Location = new System.Drawing.Point(15, 483);
            this.pnlHexLines.Name = "pnlHexLines";
            this.pnlHexLines.Size = new System.Drawing.Size(406, 57);
            this.pnlHexLines.TabIndex = 5;
            // 
            // edtHexArray
            // 
            this.edtHexArray.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.edtHexArray.Font = new System.Drawing.Font("Courier New", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edtHexArray.Location = new System.Drawing.Point(15, 547);
            this.edtHexArray.Name = "edtHexArray";
            this.edtHexArray.Size = new System.Drawing.Size(406, 18);
            this.edtHexArray.TabIndex = 6;
            this.edtHexArray.TextChanged += new System.EventHandler(this.edtHexArray_TextChanged);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Location = new System.Drawing.Point(330, 7);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(91, 23);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Очистить";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 577);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.edtHexArray);
            this.Controls.Add(this.pnlHexLines);
            this.Controls.Add(this.pnlCharImage);
            this.Controls.Add(this.edtFontHeight);
            this.Controls.Add(this.edtFontWidth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Редактор символов";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.edtFontWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edtFontHeight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown edtFontWidth;
        private System.Windows.Forms.NumericUpDown edtFontHeight;
        private System.Windows.Forms.Panel pnlCharImage;
        private System.Windows.Forms.Panel pnlHexLines;
        private System.Windows.Forms.TextBox edtHexArray;
        private System.Windows.Forms.Button btnClear;
    }
}

