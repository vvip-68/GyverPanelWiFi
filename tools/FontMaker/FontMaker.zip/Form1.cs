﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace FontMaker
{
    public partial class Form1 : Form
    {
        private List<List<Panel>> rows;
        private List<Label> rows_hex;

        private string opt_file;         // для хранения текущих настроек
        bool changing = false;

        public Form1()
        {
            InitializeComponent();
            opt_file = Path.ChangeExtension(Application.ExecutablePath, ".opt");

            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic, null, pnlCharImage, new object[] { true });
            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic, null, pnlHexLines, new object[] { true }); 
        }

        private void recreateChar(bool regenerate)
        {
            rows = new List<List<Panel>>();
            rows_hex = new List<Label>();

            var charWidth = Convert.ToByte(edtFontWidth.Value);
            var charHeight = Convert.ToByte(edtFontHeight.Value);

            var parts = edtHexArray.Text.ToUpper().Replace("{", "").Replace("}", "").Replace(" ", "").Replace("0X", "").Split(new[] { ',' }, charWidth);
            var hex = new short[charWidth];
            for (var i = 0; i < charWidth; i++)
            {
                short val = 0;
                var ok = i < parts.Length && short.TryParse(parts[i], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out val);
                hex[i] = (short) (ok ? val : 0);                
            }

            pnlCharImage.Controls.Clear();
            pnlHexLines.Controls.Clear();

            var pnl_width  = Convert.ToInt16(pnlCharImage.ClientSize.Width / charWidth);
            var pnl_height = Convert.ToInt16(pnlCharImage.ClientSize.Height / charHeight);

            var pnlSize = Math.Min(pnl_width, pnl_height);
            var offset_x = Convert.ToInt16((pnlCharImage.ClientSize.Width - charWidth * pnlSize) / 2);
            var offset_y = Convert.ToInt16((pnlCharImage.ClientSize.Height - charHeight * pnlSize) / 2);

            for (var i = 0; i < charWidth; i++)
            {
                var val = hex[i];
                var column = new List<Panel>();
                for (var j = 0; j < charHeight; j++)
                {
                    var panel = new Panel
                    {
                        Size = new Size(pnlSize, pnlSize),
                        Top = offset_y + j * (pnlSize - 1),
                        Left = offset_x + i * (pnlSize - 1),
                        BorderStyle = BorderStyle.FixedSingle
                    };
                    panel.BackColor = (val & (1 << j)) > 0 ? Color.Black : SystemColors.Window;
                    panel.MouseClick += DoMouseClick;

                    column.Add(panel);
                    pnlCharImage.Controls.Add(panel);
                }

                rows.Add(column);

                var label = new Label
                {
                    Width = 8,
                    Height = pnlHexLines.Height,
                    Top = 3
                };
                label.Left = offset_x + i * (pnlSize - 1) + (pnlSize - label.Width) / 2 - 3;
                label.Font = new Font("Courier New", 9.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
                label.Text = string.Format(charHeight <= 8 ? "0x{0:X2}" : "0x{0:X4}", val);
                label.Paint += labelPaint;

                rows_hex.Add(label);
                pnlHexLines.Controls.Add(label);
            }

            if (regenerate)
            {
                var sb = new StringBuilder();
                sb.Append("{");
                for (var i = 0; i < charWidth; i++)
                {
                    sb.Append(string.Format(charHeight <= 8 ? "0x{0:X2}" : "0x{0:X4}", hex[i]));
                    if (i < charWidth - 1) sb.Append(", ");
                }

                sb.Append("}");

                changing = true;
                edtHexArray.Text = sb.ToString();
                changing = false;
            }
        }

        private void charSizeChanged(object sender, EventArgs e)
        {
            recreateChar(true);
        }

        private void labelPaint(object sender, PaintEventArgs e)
        {
            var label = ((Label) sender);
            e.Graphics.Clear(this.BackColor);
            e.Graphics.RotateTransform(-90);
            SizeF textSize = e.Graphics.MeasureString(label.Text, label.Font);
            label.Width = (int)textSize.Height + 2;
            label.Height = (int)textSize.Width + 2;
            e.Graphics.TranslateTransform(-label.Height / 2, label.Width / 2);
            e.Graphics.DrawString(label.Text, label.Font, Brushes.Black, -(textSize.Width / 2), -(textSize.Height / 2) - 2);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            changing = true;
            edtHexArray.Text = edtHexArray.Text = createEmptyArray();
            changing = false;

            recreateChar(false);
        }

        private void pnlCharImage_Resize(object sender, EventArgs e)
        {
            recreateChar(false);
        }

        private string createEmptyArray()
        {
            var charWidth = Convert.ToByte(edtFontWidth.Value);
            var charHeight = Convert.ToByte(edtFontHeight.Value);

            var sb = new StringBuilder();
            sb.Append("{");
            for (var i = 0; i < charWidth; i++)
            {
                sb.Append(charHeight <= 8 ? "0x00" : "0x0000");
                if (i < charWidth - 1) sb.Append(", ");
            }
            sb.Append("}");
            return sb.ToString();
        }

        private string generateTextFromPanel()
        {
            var charWidth = Convert.ToByte(edtFontWidth.Value);
            var charHeight = Convert.ToByte(edtFontHeight.Value);

            var sb = new StringBuilder();
            sb.Append("{");
            for (var i = 0; i < charWidth; i++)
            {
                short val = 0;
                var col = rows[i];
                for (var j = 0; j < charHeight; j++)
                {
                    var black = col[j].BackColor == Color.Black;
                    if (black) val |= (short)(1 << j);
                }

                var str = string.Format(charHeight <= 8 ? "0x{0:X2}" : "0x{0:X4}", val);

                rows_hex[i].Text = str;

                sb.Append(str);
                if (i < charWidth - 1) sb.Append(", ");
            }
            sb.Append("}");
            return sb.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists(opt_file))
            {
                changing = true;
                try
                {
                    using (BinaryReader reader = new BinaryReader(File.Open(opt_file, FileMode.Open)))
                    {
                        edtFontWidth.Value = reader.ReadByte();
                        edtFontHeight.Value = reader.ReadByte();
                        edtHexArray.Text = reader.ReadString();
                    }
                }
                catch { }
                finally
                {
                    changing = false;
                }
            }

            if (edtHexArray.Text.Trim().Length == 0)
            {
                changing = true;
                edtHexArray.Text = createEmptyArray();
                changing = false;
            }

            recreateChar(true);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // создаем объект BinaryWriter
            try
            {
                using (var writer = new BinaryWriter(File.Open(opt_file, FileMode.Create)))
                {
                    // записываем в файл значение каждого поля структуры
                    writer.Write(Convert.ToByte(edtFontWidth.Value));
                    writer.Write(Convert.ToByte(edtFontHeight.Value));
                    writer.Write(edtHexArray.Text);
                }
            }
            catch { }

        }

        private void edtHexArray_TextChanged(object sender, EventArgs e)
        {
            if (changing) return;
            recreateChar(false);

            var text = generateTextFromPanel();
            if (text != edtHexArray.Text.Trim())
            {
                changing = true;
                edtHexArray.Text = text;
                changing = false;
            }
        }

        private void DoMouseClick(object sender, MouseEventArgs e)
        {
            var panel = (Panel)sender;
            panel.BackColor = panel.BackColor == Color.Black ? SystemColors.Window : Color.Black;

            changing = true;
            edtHexArray.Text = generateTextFromPanel();
            changing = false;
            
        }
    }
}
