// ------------- WiFi & MQTT parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "YOUR_SID"                    // Имя WiFi сети
#define NETWORK_PASS "YOUR_PWD"                    // Пароль для подключения к WiFi сети

// Для управления и отладки можно использовать одну из следующих консолей: client.mqtt.4api.ru, hivemq.com/demos/websocket-client

#undef  DEFAULT_MQTT_SERVER
#undef  DEFAULT_MQTT_USER
#undef  DEFAULT_MQTT_PASS
#undef  DEFAULT_MQTT_PORT
#undef  DEFAULT_MQTT_PREFIX

#define DEFAULT_MQTT_SERVER   "mqtt.by"             // MQTT сервер по умолчанию
#define DEFAULT_MQTT_USER     "login"               // Имя mqtt-пользователя по умолчанию 
#define DEFAULT_MQTT_PASS     "bVn7G43s"            // Пароль mqtt-пользователя по умолчанию
#define DEFAULT_MQTT_PORT     1883                  // Порт mqtt-соединения TCP по умолчанию

// API-идентификатор сервиса получения погоды
#undef  WEATHER_API_KEY
#define WEATHER_API_KEY       "553cfcc9ac3fa47794e1fb936fe66fd8"

#if (DEVICE_ID == 0)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "553cfc60"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "553cfc30"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP32
#endif
#endif

#if (DEVICE_ID == 1)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "553cfc61"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "553cfc31"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP32
#endif
#endif

