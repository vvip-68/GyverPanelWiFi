// ------------- WiFi & MQTT parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "your-ssid"                   // Имя WiFi сети
#define NETWORK_PASS "your-pass"                   // Пароль для подключения к WiFi сети

// Для управления и отладки можно использовать одну из следующих консолей: client.mqtt.4api.ru, hivemq.com/demos/websocket-client

#undef  DEFAULT_MQTT_SERVER
#undef  DEFAULT_MQTT_USER
#undef  DEFAULT_MQTT_PASS
#undef  DEFAULT_MQTT_PORT
#undef  DEFAULT_MQTT_PREFIX

#define DEFAULT_MQTT_SERVER   "mqtt.by"             // MQTT сервер по умолчанию
#define DEFAULT_MQTT_USER     "user"                // Имя mqtt-пользователя по умолчанию 
#define DEFAULT_MQTT_PASS     "frwel54a"            // Пароль mqtt-пользователя по умолчанию
#define DEFAULT_MQTT_PORT     1883                  // Порт mqtt-соединения TCP по умолчанию

// API-идентификатор сервиса получения погоды
#undef  OWM_WEATHER_API_KEY
#define OWM_WEATHER_API_KEY "6a4ba421859c9f4166697758b68d889b"

#if (DEVICE_ID == 0)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d60"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d30"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP32
#endif
#endif

#if (DEVICE_ID == 1)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d61"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d31"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP32
#endif
#endif

