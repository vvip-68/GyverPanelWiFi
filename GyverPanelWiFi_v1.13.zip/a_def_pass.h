// ------------- WiFi & MQTT parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "****"                      // Имя WiFi сети
#define NETWORK_PASS "******"                   // Пароль для подключения к WiFi сети

// Для управления и отладки можно использовать одну из следующих консолей: client.mqtt.4api.ru, hivemq.com/demos/websocket-client

#undef  DEFAULT_MQTT_SERVER
#undef  DEFAULT_MQTT_USER
#undef  DEFAULT_MQTT_PASS
#undef  DEFAULT_MQTT_PORT
#undef  DEFAULT_MQTT_PREFIX

#define DEFAULT_MQTT_SERVER   "mqtt.by"             // MQTT сервер по умолчанию
#define DEFAULT_MQTT_USER     "vvip"                // Имя mqtt-пользователя по умолчанию 
#define DEFAULT_MQTT_PASS     "ou97peht"            // Пароль mqtt-пользователя по умолчанию
#define DEFAULT_MQTT_PORT     1883                  // Порт mqtt-соединения TCP по умолчанию

// API-идентификатор сервиса получения погоды
#undef  WEATHER_API_KEY
#define WEATHER_API_KEY "6a4ba421859c9f4166697758b68d889b" // "553cfcc9ac3fa47794e1fb936fe66fd8"

#if (DEVICE_ID == 0)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d60"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d30"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP32
#endif
#endif

#if (DEVICE_ID == 1)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d61"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d31"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP32
#endif
#endif

#if (DEVICE_ID == 2)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d62"            // Префикс топика сообщения устройств DEVICE_ID == 2 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d32"            // Префикс топика сообщения устройств DEVICE_ID == 2 на ESP32
#endif
#endif

#if (DEVICE_ID == 3)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d63"            // Префикс топика сообщения устройств DEVICE_ID == 3 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d33"            // Префикс топика сообщения устройств DEVICE_ID == 3 на ESP32
#endif
#endif

#if (DEVICE_ID == 4)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d64"            // Префикс топика сообщения устройств DEVICE_ID == 4 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d34"            // Префикс топика сообщения устройств DEVICE_ID == 4 на ESP32
#endif
#endif

#if (DEVICE_ID == 5)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d65"            // Префикс топика сообщения устройств DEVICE_ID == 5 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d35"            // Префикс топика сообщения устройств DEVICE_ID == 5 на ESP32
#endif
#endif

#if (DEVICE_ID == 6)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d66"            // Префикс топика сообщения устройств DEVICE_ID == 6 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d36"            // Префикс топика сообщения устройств DEVICE_ID == 6 на ESP32
#endif
#endif

#if (DEVICE_ID == 7)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d67"            // Префикс топика сообщения устройств DEVICE_ID == 7 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d37"            // Префикс топика сообщения устройств DEVICE_ID == 7 на ESP32
#endif
#endif

#if (DEVICE_ID == 8)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d68"            // Префикс топика сообщения устройств DEVICE_ID == 8 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d38"            // Префикс топика сообщения устройств DEVICE_ID == 8 на ESP32
#endif
#endif

#if (DEVICE_ID == 9)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d69"            // Префикс топика сообщения устройств DEVICE_ID == 9 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d39"            // Префикс топика сообщения устройств DEVICE_ID == 9 на ESP32
#endif
#endif
